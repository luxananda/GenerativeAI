# Update HTML category cards (lines 125-160 area)
s/data-topic="business-analytics"/data-topic="business-analyst"/g
s/data-topic="content-discovery"/data-topic="testing-agents"/g
s/<h5 class="font-bold text-gray-900 mb-2">Business Analytics<\/h5>/<h5 class="font-bold text-gray-900 mb-2">Business Analyst Agents<\/h5>/g
s/<h5 class="font-bold text-gray-900 mb-2">Data Engineering<\/h5>/<h5 class="font-bold text-gray-900 mb-2">Data Engineering Agents<\/h5>/g
s/<h5 class="font-bold text-gray-900 mb-2">Content Discovery<\/h5>/<h5 class="font-bold text-gray-900 mb-2">Testing Agents<\/h5>/g

# Update descriptions
s/Requirements analysis, impact assessment, BRD\/FRD generation, process mapping/Requirements gathering, impact analysis, process mapping, BRD\/FRD generation/g
s/Data pipelines, ETL processes, data cleaning, modeling, and orchestration/Data onboarding, pipelines, orchestration, storage, migration, and integration/g
s/Web scraping, document analysis, metadata extraction, content synthesis/Test case creation, execution, validation, defect logging, and recommendations/g

# Update option values in select dropdown
s/<option value="business-analytics">Business Analytics<\/option>/<option value="business-analyst">Business Analyst Agents<\/option>/g
s/<option value="data-engineering">Data Engineering<\/option>/<option value="data-engineering">Data Engineering Agents<\/option>/g
s/<option value="content-discovery">Content Discovery<\/option>/<option value="testing-agents">Testing Agents<\/option>/g
s/<option value="customer-service">Customer Service<\/option>/<option value="production-support">Production Support Agents<\/option>/g

