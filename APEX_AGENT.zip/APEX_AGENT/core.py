from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import duckdb
import pandas as pd
from datetime import datetime
from data_sources import DataSourceManager, AIDataSourceAssistant

class SimpleAIAgent:
    """Simple AI agent for SQL generation and data interpretation"""
    
    def __init__(self):
        self.sql_patterns = {
            'show tables': 'SHOW TABLES',
            'list tables': 'SHOW TABLES',
            'describe table': 'DESCRIBE {}',
            'select all from': 'SELECT * FROM {} LIMIT 100',
            'count records': 'SELECT COUNT(*) as total_records FROM {}',
            'show columns': 'PRAGMA table_info({})',
        }
    
    def natural_language_to_sql(self, query: str, table_name: str = None) -> str:
        """Convert natural language to SQL query"""
        query_lower = query.lower().strip()
        
        # Basic pattern matching for simple queries
        if 'show tables' in query_lower or 'list tables' in query_lower:
            return 'SHOW TABLES'
        
        if table_name:
            if 'count' in query_lower and 'record' in query_lower:
                return f'SELECT COUNT(*) as total_records FROM {table_name}'
            
            if 'show all' in query_lower or 'select all' in query_lower:
                return f'SELECT * FROM {table_name} LIMIT 100'
            
            if 'describe' in query_lower or 'column' in query_lower:
                return f'PRAGMA table_info({table_name})'
        
        # If no pattern matches, return the query as-is (assuming it's already SQL)
        return query
    
    def generate_chart_suggestion(self, df: pd.DataFrame, query: str) -> dict:
        """Suggest appropriate chart type based on data"""
        if df.empty:
            return {"type": "no_data", "message": "No data to visualize"}
        
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        if len(numeric_cols) >= 2:
            return {
                "type": "scatter",
                "x": numeric_cols[0],
                "y": numeric_cols[1],
                "title": f"{numeric_cols[1]} vs {numeric_cols[0]}"
            }
        elif len(numeric_cols) == 1 and len(categorical_cols) >= 1:
            return {
                "type": "bar",
                "x": categorical_cols[0],
                "y": numeric_cols[0],
                "title": f"{numeric_cols[0]} by {categorical_cols[0]}"
            }
        elif len(categorical_cols) >= 1:
            return {
                "type": "pie",
                "values": categorical_cols[0],
                "title": f"Distribution of {categorical_cols[0]}"
            }
        else:
            return {
                "type": "table",
                "title": "Data Table"
            }

def create_app():
    """Create and configure FastAPI application"""
    app = FastAPI(title="Agentic Launchpad", version="1.0.0")

    # Mount static files
    app.mount("/static", StaticFiles(directory="static"), name="static")

    # Templates
    templates = Jinja2Templates(directory="templates")
    
    return app, templates

def init_sample_data(conn):
    """Create sample tables like APEX demo data"""
    try:
        # Create employees table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY,
                first_name VARCHAR(50),
                last_name VARCHAR(50),
                email VARCHAR(100),
                department VARCHAR(50),
                salary DECIMAL(10,2),
                hire_date DATE
            )
        """)
        
        # Insert sample data
        sample_employees = [
            (1, 'John', 'Doe', 'john.doe@company.com', 'Engineering', 75000, '2023-01-15'),
            (2, 'Jane', 'Smith', 'jane.smith@company.com', 'Marketing', 65000, '2023-02-20'),
            (3, 'Bob', 'Johnson', 'bob.johnson@company.com', 'Engineering', 80000, '2022-11-10'),
            (4, 'Alice', 'Brown', 'alice.brown@company.com', 'Sales', 70000, '2023-03-05'),
            (5, 'Charlie', 'Wilson', 'charlie.wilson@company.com', 'HR', 60000, '2023-01-30'),
        ]
        
        conn.execute("DELETE FROM employees")  # Clear existing data
        conn.executemany(
            "INSERT INTO employees VALUES (?, ?, ?, ?, ?, ?, ?)",
            sample_employees
        )
        
        # Create sales table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY,
                product_name VARCHAR(100),
                sales_amount DECIMAL(10,2),
                sale_date DATE,
                region VARCHAR(50)
            )
        """)
        
        sample_sales = [
            (1, 'Product A', 15000, '2023-11-01', 'North'),
            (2, 'Product B', 25000, '2023-11-02', 'South'),
            (3, 'Product A', 18000, '2023-11-03', 'East'),
            (4, 'Product C', 30000, '2023-11-04', 'West'),
            (5, 'Product B', 22000, '2023-11-05', 'North'),
        ]
        
        conn.execute("DELETE FROM sales")
        conn.executemany(
            "INSERT INTO sales VALUES (?, ?, ?, ?, ?)",
            sample_sales
        )
        
    except Exception as e:
        print(f"Error initializing sample data: {e}")

def setup_basic_routes(app, templates):
    """Setup basic application routes"""
    
    @app.get("/")
    async def home(request: Request):
        """Redirect to Agent Dashboard (main page is now agent-focused)"""
        return RedirectResponse(url="/agents", status_code=302)

    @app.get("/.devtools.json")
    async def devtools_config():
        """Handle devtools.json requests to prevent 404 errors"""
        return JSONResponse({
            "name": "Agentic Launchpad",
            "version": "1.0.0",
            "devtools": {
                "enabled": True
            }
        })

    @app.get("/favicon.ico")
    async def favicon():
        """Handle favicon requests to prevent 404 errors"""
        return Response(status_code=204)  # No Content

    @app.get("/robots.txt")
    async def robots():
        """Handle robots.txt requests"""
        return Response(content="User-agent: *\nDisallow:", media_type="text/plain")

    # Keep old dashboard route hidden but functional for later use
    @app.get("/old-dashboard", response_class=HTMLResponse)
    async def old_dashboard(request: Request):
        """Old data dashboard page (hidden but preserved)"""
        return templates.TemplateResponse("index.html", {"request": request})

    # Keep old app builder route hidden but functional for later use
    @app.get("/old-app-builder", response_class=HTMLResponse)
    async def old_app_builder(request: Request):
        """Old app builder interface (hidden but preserved)"""
        return templates.TemplateResponse("app_builder.html", {"request": request})

    # Keep old data sources route hidden but functional for later use
    @app.get("/old-data-sources", response_class=HTMLResponse)
    async def old_data_sources_page(request: Request):
        """Old data sources configuration page (hidden but preserved)"""
        return templates.TemplateResponse("data_sources.html", {"request": request})

def get_globals():
    """Get global objects for sharing between modules"""
    # Initialize DuckDB connection
    conn = duckdb.connect('app_data.db')
    
    # Initialize AI agent
    ai_agent = SimpleAIAgent()
    
    # Initialize managers
    data_source_manager = DataSourceManager()
    ai_assistant = AIDataSourceAssistant()
    
    # Store for deployed applications
    deployed_apps = {}
    app_counter = 1
    
    # Initialize sample data
    init_sample_data(conn)
    
    # Test that ai_assistant is working correctly
    print("AI Assistant initialized - testing guidance...")
    test_result = ai_assistant.get_connection_guidance('postgresql')
    print(f"Test result has drivers: {'drivers' in test_result.get('guidance', {})}")
    
    return {
        'conn': conn,
        'ai_agent': ai_agent,
        'data_source_manager': data_source_manager,
        'ai_assistant': ai_assistant,
        'deployed_apps': deployed_apps,
        'app_counter': app_counter
    } 