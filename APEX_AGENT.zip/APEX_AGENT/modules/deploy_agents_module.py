from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from datetime import datetime
import asyncio
import random

def setup_deploy_agents_routes(app, templates, agent_stores):
    """Setup deploy agents related routes"""

    @app.get("/deploy-agents")
    async def deploy_agents(request: Request):
        """Deploy Agents - Manage and monitor deployed AI agents"""
        return templates.TemplateResponse("deploy_agents.html", {"request": request})

    @app.get("/api/agents")
    async def list_agents():
        """List all created agents"""
        all_agents = []
        
        # Get agents from all stores
        for store_name, store in agent_stores.items():
            if hasattr(store, 'values') and callable(getattr(store, 'values')) and isinstance(store, dict):
                all_agents.extend(list(store.values()))
            else:
                print(f"Warning: Store '{store_name}' is not a dictionary: {type(store)}")
        
        # Add sample agents for demo only if no real agents exist
        if not all_agents:
            sample_agents = [
                {
                    "id": "demo_agent_001",
                    "name": "Demo Investment Analyzer",
                    "description": "Sample agent for investment analysis",
                    "category": "business-analyst",
                    "type": "investment-analysis",
                    "status": "active",
                    "created_at": "2024-01-15T10:30:00Z"
                },
                {
                    "id": "demo_agent_002", 
                    "name": "Demo Data Processor",
                    "description": "Sample agent for data processing",
                    "category": "data-engineering",
                    "type": "data-migration",
                    "status": "active",
                    "created_at": "2024-01-14T09:15:00Z"
                },
                {
                    "id": "demo_agent_003", 
                    "name": "Demo AI Assistant",
                    "description": "Sample conversational agent powered by ChatGPT/Claude",
                    "category": "conversational",
                    "type": "conversational",
                    "status": "active",
                    "created_at": "2024-01-16T11:45:00Z"
                }
            ]
            all_agents.extend(sample_agents)
        
        # Sort agents by creation date (newest first)
        all_agents.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        return JSONResponse({
            "agents": all_agents,
            "count": len(all_agents),
            "success": True
        })

    @app.get("/api/agents/{agent_id}")
    async def get_agent(agent_id: str):
        """Get agent details"""
        # Check in all agent stores
        for store in agent_stores.values():
            if hasattr(store, 'get') and callable(getattr(store, 'get')) and isinstance(store, dict):
                if agent_id in store:
                    agent = store[agent_id]
                    return JSONResponse({"agent": agent})
        
        # Demo agents (fallback)
        demo_agents = {
            "demo_agent_001": {
                "id": "demo_agent_001",
                "name": "Demo Investment Analyzer",
                "description": "Sample agent for investment analysis",
                "category": "business-analyst",
                "type": "investment-analysis",
                "status": "active"
            },
            "demo_agent_002": {
                "id": "demo_agent_002",
                "name": "Demo Data Processor", 
                "description": "Sample agent for data processing",
                "category": "data-engineering",
                "type": "data-migration",
                "status": "active"
            }
        }
        
        if agent_id in demo_agents:
            return JSONResponse({"agent": demo_agents[agent_id]})
        
        raise HTTPException(status_code=404, detail="Agent not found")

    # Agent Execution Interface
    @app.get("/agent/{agent_id}")
    async def agent_interface(agent_id: str, request: Request):
        """Serve agent execution interface"""
        # Get agent details
        agent = None
        
        for store in agent_stores.values():
            if hasattr(store, 'get') and callable(getattr(store, 'get')) and isinstance(store, dict):
                if agent_id in store:
                    agent = store[agent_id]
                    break
        
        if not agent:
            # Demo agents fallback
            demo_agents = {
                "demo_agent_001": {
                    "id": "demo_agent_001",
                    "name": "Demo Investment Analyzer",
                    "description": "Sample agent for investment analysis",
                    "category": "business-analyst",
                    "type": "investment-analysis"
                },
                "demo_agent_002": {
                    "id": "demo_agent_002",
                    "name": "Demo Data Processor",
                    "description": "Sample agent for data processing",
                    "category": "data-engineering",
                    "type": "data-migration"
                }
            }
            
            if agent_id in demo_agents:
                agent = demo_agents[agent_id]
        
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")
        
        # Generate agent interface HTML
        agent_html = f"""<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{agent['name']} - Agentic Launchpad</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/static/gic_theme.css">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="gic-header">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-robot text-white text-lg"></i>
                        </div>
                        <div>
                            <h1 class="text-xl font-bold text-white">{agent['name']}</h1>
                            <p class="text-xs text-blue-200">{agent.get('category', 'Agent').title()} Agent</p>
                        </div>
                    </div>
                    <nav class="flex space-x-2">
                        <a href="/agents" class="gic-nav-link">← Back to Dashboard</a>
                        <a href="/deploy-agents" class="gic-nav-link">Deploy Agents</a>
                    </nav>
                </div>
            </div>
        </header>

        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Agent Info -->
            <div class="gic-card p-6 mb-8">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900">{agent['name']}</h2>
                        <p class="text-gray-600">{agent.get('description', 'AI Agent Interface')}</p>
                    </div>
                    <div class="flex space-x-2">
                        <span class="gic-badge gic-badge-primary">{agent.get('category', 'general')}</span>
                        <span class="gic-badge gic-badge-success">Active</span>
                    </div>
                </div>
            </div>

            <!-- Chat Interface -->
            <div class="gic-card p-6">
                <h3 class="text-lg font-semibold mb-4 text-gray-800">
                    <i class="fas fa-comments mr-3 text-blue-600"></i>Chat with {agent['name']}
                </h3>
                
                <!-- Messages Area -->
                <div id="messagesArea" class="bg-gray-50 rounded-lg p-4 h-96 overflow-y-auto mb-4">
                    <div class="gic-chat-message">
                        <div class="gic-message-bubble bg-blue-100 text-blue-900 ml-auto">
                            <strong>System:</strong> {agent['name']} is ready to assist you!
                        </div>
                    </div>
                </div>

                <!-- Input Area -->
                <div class="flex space-x-3">
                    <input 
                        type="text" 
                        id="messageInput" 
                        class="gic-input flex-1" 
                        placeholder="Type your message here..."
                        onkeypress="if(event.key==='Enter') sendMessage()"
                    >
                    <button id="sendBtn" onclick="sendMessage()" class="gic-btn gic-btn-primary">
                        <i class="fas fa-paper-plane mr-2"></i>Send
                    </button>
                </div>
            </div>

            <!-- Agent Details -->
            <div class="gic-card p-6 mt-8">
                <h3 class="text-lg font-semibold mb-4 text-gray-800">
                    <i class="fas fa-info-circle mr-3 text-blue-600"></i>Agent Details
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <p class="text-sm font-medium text-gray-700">Agent ID</p>
                        <p class="text-sm text-gray-600">{agent['id']}</p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-700">Category</p>
                        <p class="text-sm text-gray-600">{agent.get('category', 'N/A')}</p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-700">Type</p>
                        <p class="text-sm text-gray-600">{agent.get('type', 'N/A')}</p>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-700">Status</p>
                        <p class="text-sm text-gray-600">{agent.get('status', 'Active')}</p>
                    </div>
                </div>
            </div>
        </div>

        <script>
            const agentId = '{agent['id']}';
            const agentEndpoint = '{agent.get('endpoint', '')}';
            const outputType = '{agent.get('output_type', 'chat')}';
            const inputType = '{agent.get('input_type', 'chat')}';

            async function sendMessage() {{
                const input = document.getElementById('messageInput');
                const sendBtn = document.getElementById('sendBtn');
                const messagesArea = document.getElementById('messagesArea');
                
                const message = input.value.trim();
                if (!message) return;

                // Add user message
                addMessage(message, 'user');
                input.value = '';
                
                // Show loading
                sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
                sendBtn.disabled = true;

                try {{
                    // Call agent API
                    const response = await fetch('/api/agent/execute', {{
                        method: 'POST',
                        headers: {{
                            'Content-Type': 'application/json',
                        }},
                        body: JSON.stringify({{
                            agent_id: agentId,
                            message: message,
                            endpoint: agentEndpoint,
                            input_type: inputType,
                            output_type: outputType
                        }})
                    }});

                    const result = await response.json();
                    
                    if (result.success) {{
                        addMessage(result.response, 'agent');
                    }} else {{
                        addMessage('Error: ' + result.error, 'error');
                    }}
                }} catch (error) {{
                    addMessage('Error: Failed to communicate with agent', 'error');
                }} finally {{
                    sendBtn.innerHTML = '<i class="fas fa-paper-plane mr-2"></i>Send';
                    sendBtn.disabled = false;
                }}
            }}

            function addMessage(message, type) {{
                const messagesArea = document.getElementById('messagesArea');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'gic-chat-message';
                
                let bubbleClass = '';
                let sender = '';
                
                switch(type) {{
                    case 'user':
                        bubbleClass = 'gic-message-bubble bg-blue-600 text-white ml-auto';
                        sender = 'You';
                        break;
                    case 'agent':
                        bubbleClass = 'gic-message-bubble bg-white border border-gray-200';
                        sender = '{agent['name']}';
                        break;
                    case 'error':
                        bubbleClass = 'gic-message-bubble bg-red-100 text-red-900';
                        sender = 'System';
                        break;
                }}
                
                messageDiv.innerHTML = `
                    <div class="${{bubbleClass}}">
                        <strong>${{sender}}:</strong> ${{message}}
                    </div>
                `;
                
                messagesArea.appendChild(messageDiv);
                messagesArea.scrollTop = messagesArea.scrollHeight;
            }}
        </script>
    </body>
    </html>"""
        
        return HTMLResponse(content=agent_html)

    @app.post("/api/agent/execute")
    async def execute_agent(request: Request):
        """Execute agent with user input"""
        try:
            data = await request.json()
            agent_id = data.get("agent_id")
            message = data.get("message")
            endpoint = data.get("endpoint")
            input_type = data.get("input_type", "chat")
            output_type = data.get("output_type", "chat")
            
            # If no endpoint in request, try to get it from agent configuration
            if not endpoint and agent_id:
                for store in agent_stores.values():
                    if hasattr(store, 'get') and callable(getattr(store, 'get')) and isinstance(store, dict):
                        if agent_id in store:
                            agent = store[agent_id]
                            endpoint = agent.get('endpoint', '')
                            break
            
            # If it's a Langflow API agent (API or JSON), call the actual endpoint
            if endpoint and endpoint.startswith("http"):
                try:
                    import httpx
                    import time
                    
                    # For Langflow chat flows, we need to use the session-based approach
                    # First, extract session_id from the endpoint if it exists
                    session_id = endpoint.split('/')[-1] if '/' in endpoint else None
                    
                    # Try different endpoints and payload formats for Langflow chat flows
                    endpoints_and_payloads = [
                        # Try chat endpoint first
                        (endpoint.replace('/run/', '/chat/'), {
                            "message": message,
                            "session_id": session_id or "default_session"
                        }),
                        # Try run endpoint with component targeting
                        (endpoint, {
                            "inputs": {
                                "ChatInput-JiXql": {
                                    "input_value": message
                                }
                            },
                            "tweaks": {}
                        }),
                        # Try run endpoint with tweaks targeting the input component
                        (endpoint, {
                            "inputs": {
                                "input_value": message
                            },
                            "tweaks": {
                                "ChatInput-JiXql": {
                                    "input_value": message
                                }
                            }
                        }),
                        # Try simple input_value format
                        (endpoint, {
                            "inputs": {
                                "input_value": message
                            },
                            "tweaks": {}
                        }),
                        # Try direct message format
                        (endpoint, {
                            "message": message,
                            "tweaks": {}
                        })
                    ]
                    
                    headers = {
                        "Content-Type": "application/json"
                    }
                    
                    start_time = time.time()
                    response = None
                    
                    # Try each endpoint and payload combination until one works
                    for i, (test_endpoint, payload) in enumerate(endpoints_and_payloads):
                        try:
                            async with httpx.AsyncClient(timeout=30.0) as client:
                                response = await client.post(
                                    test_endpoint,
                                    json=payload,
                                    headers=headers
                                )
                                
                                if response.status_code < 400:
                                    # Check if the response contains the user's actual message or a proper response
                                    response_text = response.text
                                    # Look for signs that the input was processed correctly
                                    message_processed = (
                                        message.lower() in response_text.lower() or 
                                        not ("empty" in response_text.lower() or "blank" in response_text.lower() or "still coming through empty" in response_text.lower())
                                    )
                                    
                                    if message_processed:
                                        # This format worked, use this response
                                        break
                                    
                        except Exception as e:
                            continue
                    
                    # If none of the formats worked, fall back to the last response or create an error
                    if response is None:
                        return JSONResponse({
                            "success": False,
                            "error": "All payload formats failed for this Langflow flow"
                        })
                    
                    response_time = round((time.time() - start_time) * 1000, 2)
                    
                    if response.status_code < 400:
                        # Try to extract the response text from Langflow's response
                        try:
                            response_data = response.json()
                            # Langflow often returns responses in different formats
                            # Try to extract the actual text response
                            if isinstance(response_data, dict):
                                # Look for common response keys in Langflow response structure
                                response_text = (
                                    response_data.get("outputs", [{}])[0].get("outputs", [{}])[0].get("results", {}).get("message", {}).get("data", {}).get("text") or
                                    response_data.get("outputs", {}).get("text") or
                                    response_data.get("result") or
                                    response_data.get("response") or
                                    response_data.get("output") or
                                    str(response_data)
                                )
                            else:
                                response_text = str(response_data)
                        except:
                            # If JSON parsing fails, use raw text
                            response_text = response.text
                        
                        return JSONResponse({
                            "success": True,
                            "response": response_text,
                            "response_time": f"{response_time}ms",
                            "status_code": response.status_code
                        })
                    else:
                        return JSONResponse({
                            "success": False,
                            "error": f"API returned status {response.status_code}",
                            "response_time": f"{response_time}ms",
                            "response_preview": response.text[:200] + "..." if len(response.text) > 200 else response.text
                        })
                    
                except httpx.TimeoutException:
                    return JSONResponse({
                        "success": False,
                        "error": "Request timed out. The API endpoint took too long to respond (>30 seconds)."
                    })
                except httpx.ConnectError:
                    return JSONResponse({
                        "success": False,
                        "error": "Could not connect to the API endpoint. Please check if the Langflow service is running."
                    })
                except Exception as e:
                    return JSONResponse({
                        "success": False,
                        "error": f"Failed to call Langflow API: {str(e)}"
                    })
            else:
                # Demo response for non-API agents
                responses = [
                    f"Thank you for your message: '{message}'. I'm processing this request...",
                    f"Based on your input '{message}', here are my thoughts...",
                    f"I understand you're asking about '{message}'. Let me help you with that.",
                    f"Your message '{message}' has been analyzed. Here's what I found..."
                ]
                
                response_text = random.choice(responses)
                
                return JSONResponse({
                    "success": True,
                    "response": response_text
                })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500) 