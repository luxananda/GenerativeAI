"""
Modules package for Agentic Launchpad
Contains modularized functionality organized by template themes.
"""

__version__ = "1.0.0" 