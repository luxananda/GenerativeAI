from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates

def setup_data_pipeline_routes(app, templates):
    """Setup data pipeline related routes"""

    @app.get("/data-pipeline-chat")
    async def data_pipeline_chat(request: Request):
        """Serve the AI data pipeline chat interface"""
        return templates.TemplateResponse("data_pipeline_chat.html", {"request": request})

    @app.post("/api/ai-pipeline-request")
    async def process_pipeline_request(request: Request):
        """Process natural language pipeline requests"""
        try:
            data = await request.json()
            message = data.get("message", "")
            
            # Here you would integrate with a proper NLP model
            # For now, using simple keyword matching as demonstration
            
            response = {
                "message": "I understand your request! This would be processed by a proper NLP model in production.",
                "sql": "SELECT * FROM your_table WHERE condition = 'value'",
                "pipeline_step": {
                    "type": "transform",
                    "description": "Data transformation step",
                    "status": "ready"
                }
            }
            
            return JSONResponse(response)
            
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500) 