from fastapi import Request

def setup_agent_dashboard_routes(app, templates):
    """Setup agent dashboard related routes"""

    @app.get("/agents")
    async def agent_dashboard(request: Request):
        """Agent Dashboard - Main hub for AI agent management"""
        return templates.TemplateResponse("agent_dashboard.html", {"request": request}) 