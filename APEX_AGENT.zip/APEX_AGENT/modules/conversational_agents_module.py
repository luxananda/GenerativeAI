from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from datetime import datetime
import openai
import anthropic

def setup_conversational_agents_routes(app, templates):
    """Setup conversational agents related routes"""

    # Store for conversational agents (in production, use a database)
    conversational_agents = {}

    @app.get("/conversational-agents")
    async def conversational_agents(request: Request):
        """Conversational Agents - Natural language agent creation using Langgraph"""
        return templates.TemplateResponse("conversational_agents.html", {"request": request})

    @app.post("/api/conversational/test-connection")
    async def test_conversational_connection(request: Request):
        """Test API connection for conversational agents"""
        try:
            data = await request.json()
            provider = data.get("provider")
            api_key = data.get("apiKey")
            model = data.get("model")
            
            if provider == "openai":
                # Test OpenAI connection
                openai.api_key = api_key
                response = openai.ChatCompletion.create(
                    model=model,
                    messages=[{"role": "user", "content": "Test connection"}],
                    max_tokens=10,
                    temperature=0.1
                )
                return JSONResponse({"success": True, "message": "OpenAI connection successful"})
                
            elif provider == "claude":
                # Test Claude connection
                client = anthropic.Anthropic(api_key=api_key)
                response = client.messages.create(
                    model=model,
                    max_tokens=10,
                    messages=[{"role": "user", "content": "Test connection"}]
                )
                return JSONResponse({"success": True, "message": "Claude connection successful"})
                
            else:
                return JSONResponse({"success": False, "error": "Unsupported provider"}, status_code=400)
                
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/conversational/create-agent")
    async def create_conversational_agent(request: Request):
        """Create a new conversational agent"""
        try:
            data = await request.json()
            
            agent_id = f"conv_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            agent_config = {
                "id": agent_id,
                "name": data.get("name"),
                "category": data.get("category", "general"),
                "systemPrompt": data.get("systemPrompt"),
                "temperature": data.get("temperature", 0.7),
                "maxTokens": data.get("maxTokens", 1024),
                "provider": data.get("provider"),
                "model": data.get("model"),
                "type": "conversational",
                "status": "active",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            # Store the agent (without API key for security)
            conversational_agents[agent_id] = agent_config
            
            print(f"✅ Conversational Agent created: {agent_config['name']} ({agent_id})")
            print(f"   Provider: {agent_config['provider']}")
            print(f"   Model: {agent_config['model']}")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_id,
                "message": f"🎉 Conversational agent '{agent_config['name']}' created successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.get("/api/conversational/agents")
    async def get_conversational_agents():
        """Get all conversational agents"""
        try:
            agents_list = list(conversational_agents.values())
            agents_list.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            
            return JSONResponse({
                "success": True,
                "agents": agents_list
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/conversational/chat")
    async def conversational_chat(request: Request):
        """Handle chat with conversational agents"""
        try:
            data = await request.json()
            message = data.get("message")
            agent = data.get("agent")
            api_key = data.get("apiKey")
            
            if not message or not agent:
                return JSONResponse({"success": False, "error": "Missing message or agent configuration"}, status_code=400)
            
            provider = agent.get("provider")
            model = agent.get("model")
            system_prompt = agent.get("systemPrompt", "You are a helpful assistant.")
            temperature = agent.get("temperature", 0.7)
            max_tokens = agent.get("maxTokens", 1024)
            
            if provider == "openai":
                # OpenAI ChatGPT
                openai.api_key = api_key
                
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": message}
                ]
                
                response = openai.ChatCompletion.create(
                    model=model,
                    messages=messages,
                    max_tokens=max_tokens,
                    temperature=temperature
                )
                
                ai_response = response.choices[0].message.content.strip()
                
            elif provider == "claude":
                # Anthropic Claude
                client = anthropic.Anthropic(api_key=api_key)
                
                # For Claude, we include system prompt in the user message
                full_message = f"System: {system_prompt}\n\nUser: {message}"
                
                response = client.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    messages=[{"role": "user", "content": full_message}]
                )
                
                ai_response = response.content[0].text.strip()
                
            else:
                return JSONResponse({"success": False, "error": "Unsupported provider"}, status_code=400)
            
            return JSONResponse({
                "success": True,
                "response": ai_response,
                "provider": provider,
                "model": model
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    return conversational_agents 