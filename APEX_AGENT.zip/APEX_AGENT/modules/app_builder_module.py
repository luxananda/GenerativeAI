from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from datetime import datetime
import json

def setup_app_builder_routes(app, templates, globals_dict):
    """Setup app builder related routes"""
    
    deployed_apps = globals_dict['deployed_apps']

    @app.post("/api/deploy-app")
    async def deploy_app(request: Request):
        """Deploy an application"""
        try:
            data = await request.json()
            
            # Generate unique app ID and URL
            app_counter = globals_dict['app_counter']
            app_id = f"app_{app_counter:04d}"
            app_url = f"/deployed/{app_id}"
            globals_dict['app_counter'] += 1
            
            # Save app configuration
            app_config = {
                "id": app_id,
                "name": data.get("name", f"App {app_id}"),
                "template": data.get("template"),
                "data_source": data.get("dataSource"),
                "table": data.get("table"),
                "form_html": data.get("formHtml"),
                "created_at": datetime.now().isoformat(),
                "url": app_url,
                "status": "active"
            }
            
            deployed_apps[app_id] = app_config
            
            # Save to file for persistence
            with open("deployed_apps.json", "w") as f:
                json.dump(deployed_apps, f, indent=2)
            
            print(f"✅ App deployed successfully: {app_id} -> {app_url}")
            
            return JSONResponse({
                "success": True,
                "app_id": app_id,
                "url": app_url,
                "message": f"Application deployed successfully! Access it at: {app_url}"
            })
            
        except Exception as e:
            print(f"❌ Deployment error: {str(e)}")
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.get("/deployed/{app_id}")
    async def serve_deployed_app(app_id: str):
        """Serve a deployed application"""
        if app_id not in deployed_apps:
            raise HTTPException(status_code=404, detail="Application not found")
        
        app_config = deployed_apps[app_id]
        
        # Generate the deployed app HTML
        deployed_html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{app_config['name']} - Deployed App</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            .form-control {{
                margin: 8px 0;
                padding: 12px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                background: white;
            }}
        </style>
    </head>
    <body class="bg-gray-50 min-h-screen">
        <div class="max-w-4xl mx-auto py-8">
            <!-- App Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">{app_config['name']}</h1>
                        <p class="text-gray-600">Powered by Agentic Launchpad</p>
                    </div>
                    <div class="text-sm text-gray-500">
                        <i class="fas fa-database mr-1"></i>{app_config['data_source']} → {app_config['table']}
                    </div>
                </div>
            </div>
            
            <!-- Deployed Application -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="max-w-2xl mx-auto">
                    <form id="deployedForm" class="space-y-4">
                        {app_config['form_html']}
                    </form>
                </div>
            </div>
            
            <!-- App Footer -->
            <div class="text-center mt-6 text-gray-500 text-sm">
                <p>Deployed on {app_config['created_at'][:10]} | 
                <a href="/app-builder" class="text-blue-600 hover:underline">Build Your Own App</a></p>
            </div>
        </div>
        
        <script>
            // Remove control handles and make form functional
            document.querySelectorAll('.control-handle').forEach(handle => handle.remove());
            
            // Add form submission handling
            document.getElementById('deployedForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                // Collect form data
                const formData = new FormData(this);
                const data = Object.fromEntries(formData.entries());
                
                // Show success message (in real app, this would save to database)
                alert('Form submitted successfully!\\n\\nData: ' + JSON.stringify(data, null, 2));
            }});
            
            // Make form inputs functional
            document.querySelectorAll('input, select, textarea').forEach(input => {{
                if (!input.name && input.type !== 'button' && input.type !== 'submit') {{
                    // Generate name from label or placeholder
                    const label = input.previousElementSibling;
                    if (label && label.tagName === 'LABEL') {{
                        input.name = label.textContent.toLowerCase().replace(/[^a-z0-9]/g, '_');
                    }}
                }}
            }});
        </script>
    </body>
    </html>
        """
        
        return HTMLResponse(content=deployed_html)

    # Keep old deployed apps route hidden but functional for later use  
    @app.get("/old-deployed-apps")
    async def old_deployed_apps_page(request: Request):
        """Old deployed apps management page (hidden but preserved)"""
        return templates.TemplateResponse("deployed_apps.html", {"request": request})

    @app.get("/api/deployed-apps")
    async def list_deployed_apps():
        """List all deployed applications"""
        apps_list = [
            {
                "id": app_id,
                "name": config["name"],
                "template": config["template"],
                "url": config["url"],
                "created_at": config["created_at"],
                "status": config["status"]
            }
            for app_id, config in deployed_apps.items()
        ]
        
        return JSONResponse({"apps": apps_list})

    @app.delete("/api/deployed-apps/{app_id}")
    async def delete_deployed_app(app_id: str):
        """Delete a deployed application"""
        if app_id not in deployed_apps:
            raise HTTPException(status_code=404, detail="Application not found")
        
        del deployed_apps[app_id]
        
        # Update persistent storage
        with open("deployed_apps.json", "w") as f:
            json.dump(deployed_apps, f, indent=2)
        
        return JSONResponse({"success": True, "message": "Application deleted successfully"}) 