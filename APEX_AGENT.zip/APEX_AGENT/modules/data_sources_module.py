from fastapi import Request, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse
import duckdb
import pandas as pd
import plotly.express as px
import os
from pathlib import Path

def setup_data_source_routes(app, globals_dict):
    """Setup data source related routes"""
    
    conn = globals_dict['conn']
    ai_agent = globals_dict['ai_agent']
    data_source_manager = globals_dict['data_source_manager']
    ai_assistant = globals_dict['ai_assistant']

    @app.get("/api/tables")
    async def get_tables():
        """Get list of available tables"""
        try:
            result = conn.execute("SHOW TABLES").fetchall()
            tables = [row[0] for row in result]
            return {"tables": tables}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/query")
    async def execute_query(request: Request):
        """Execute SQL query or natural language query"""
        try:
            data = await request.json()
            query = data.get("query", "")
            table_name = data.get("table_name")
            use_ai = data.get("use_ai", False)
            
            if use_ai:
                # Convert natural language to SQL
                sql_query = ai_agent.natural_language_to_sql(query, table_name)
            else:
                sql_query = query
            
            # Execute query
            result = conn.execute(sql_query).fetchall()
            columns = [desc[0] for desc in conn.description]
            
            # Convert to DataFrame for easier manipulation
            df = pd.DataFrame(result, columns=columns)
            
            # Generate chart suggestion
            chart_suggestion = ai_agent.generate_chart_suggestion(df, query)
            
            return {
                "sql_query": sql_query,
                "data": df.to_dict(orient="records"),
                "columns": columns,
                "row_count": len(df),
                "chart_suggestion": chart_suggestion
            }
        
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/generate-chart")
    async def generate_chart(request: Request):
        """Generate chart from data"""
        try:
            data = await request.json()
            chart_data = data.get("data", [])
            chart_type = data.get("type", "bar")
            x_col = data.get("x")
            y_col = data.get("y")
            title = data.get("title", "Chart")
            
            df = pd.DataFrame(chart_data)
            
            if chart_type == "bar":
                fig = px.bar(df, x=x_col, y=y_col, title=title)
            elif chart_type == "scatter":
                fig = px.scatter(df, x=x_col, y=y_col, title=title)
            elif chart_type == "pie":
                value_counts = df[x_col].value_counts()
                fig = px.pie(values=value_counts.values, names=value_counts.index, title=title)
            else:
                fig = px.bar(df, x=x_col, y=y_col, title=title)
            
            # Convert to JSON
            chart_json = fig.to_json()
            
            return {"chart": chart_json}
        
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/api/data-sources")
    async def get_data_sources():
        """Get list of configured data sources"""
        try:
            sources = data_source_manager.list_data_sources()
            # Add DuckDB as default source
            sources.insert(0, {
                'name': 'duckdb',
                'type': 'duckdb',
                'status': 'active',
                'tables': ['employees', 'sales']
            })
            return {"data_sources": sources}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/data-sources")
    async def add_data_source(request: Request):
        """Add new data source"""
        try:
            data = await request.json()
            name = data.get("name")
            source_type = data.get("type")
            config = data.get("config", {})
            
            result = data_source_manager.add_data_source(name, source_type, config)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/data-sources/test")
    async def test_data_source(request: Request):
        """Test data source connection"""
        try:
            data = await request.json()
            source_type = data.get("type")
            config = data.get("config", {})
            
            result = data_source_manager.test_connection(source_type, config)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/api/data-sources/{source_name}/tables")
    async def get_source_tables(source_name: str):
        """Get tables from specific data source"""
        try:
            if source_name == 'duckdb':
                conn = duckdb.connect('app_data.db')
                result = conn.execute("SHOW TABLES").fetchall()
                tables = [row[0] for row in result]
            else:
                sources = data_source_manager.list_data_sources()
                source = next((s for s in sources if s['name'] == source_name), None)
                if not source:
                    raise HTTPException(status_code=404, detail="Data source not found")
                tables = source.get('tables', [])
            
            return {"tables": tables}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/query-multi-source")
    async def execute_multi_source_query(request: Request):
        """Execute query on specified data source"""
        try:
            data = await request.json()
            source_name = data.get("source_name", "duckdb")
            query = data.get("query", "")
            table_name = data.get("table_name")
            use_ai = data.get("use_ai", False)
            
            if use_ai:
                # Convert natural language to SQL
                sql_query = ai_agent.natural_language_to_sql(query, table_name)
            else:
                sql_query = query
            
            # Execute query on specified data source
            if source_name == 'duckdb':
                conn = duckdb.connect('app_data.db')
                result = conn.execute(sql_query).fetchall()
                columns = [desc[0] for desc in conn.description]
            else:
                df = data_source_manager.execute_query(source_name, sql_query)
                result = df.values.tolist()
                columns = df.columns.tolist()
            
            # Convert to DataFrame for consistency
            df = pd.DataFrame(result, columns=columns)
            
            # Generate chart suggestion
            chart_suggestion = ai_agent.generate_chart_suggestion(df, query)
            
            return {
                "sql_query": sql_query,
                "data": df.to_dict(orient="records"),
                "columns": columns,
                "row_count": len(df),
                "chart_suggestion": chart_suggestion,
                "source_name": source_name
            }
        
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/api/table-info/{source_name}/{table_name}")
    async def get_multi_source_table_info(source_name: str, table_name: str):
        """Get table structure information from any data source"""
        try:
            if source_name == 'duckdb':
                conn = duckdb.connect('app_data.db')
                result = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
                columns = []
                for row in result:
                    columns.append({
                        "name": row[1],
                        "type": row[2],
                        "nullable": not row[3],
                        "primary_key": bool(row[5])
                    })
            else:
                table_info = data_source_manager.get_table_info(source_name, table_name)
                columns = table_info.get('columns', [])
            
            return {"table_name": table_name, "columns": columns, "source_name": source_name}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/upload-file")
    async def upload_file(file: UploadFile = File(...)):
        """Upload and process data file"""
        try:
            # Create uploads directory if it doesn't exist
            upload_dir = Path("uploads")
            upload_dir.mkdir(exist_ok=True)
            
            # Save uploaded file
            file_path = upload_dir / file.filename
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            # Process file
            result = data_source_manager.upload_file(str(file_path), file.filename)
            
            # Clean up temporary file
            os.unlink(file_path)
            
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")

    @app.get("/api/connection-guidance/{source_type}")
    async def get_connection_guidance(source_type: str):
        """Get AI-powered guidance for connecting to data source"""
        try:
            guidance = ai_assistant.get_connection_guidance(source_type)
            return guidance
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.post("/api/ai-connection-help")
    async def ai_connection_help(request: Request):
        """Get AI assistance for connection troubleshooting"""
        try:
            data = await request.json()
            source_type = data.get("source_type")
            error_message = data.get("error_message", "")
            config = data.get("config", {})
            
            # Simple AI-powered troubleshooting
            suggestions = []
            
            if "authentication" in error_message.lower() or "login" in error_message.lower():
                suggestions.append("Check username and password credentials")
                suggestions.append("Verify user has necessary permissions")
                suggestions.append("Confirm account is not locked")
            
            if "connection" in error_message.lower() or "timeout" in error_message.lower():
                suggestions.append("Verify host and port are correct")
                suggestions.append("Check network connectivity")
                suggestions.append("Ensure firewall allows connections")
            
            if "database" in error_message.lower() or "schema" in error_message.lower():
                suggestions.append("Confirm database/schema name is correct")
                suggestions.append("Check if database exists and is accessible")
            
            if not suggestions:
                suggestions.append("Check connection parameters")
                suggestions.append("Verify service is running")
                suggestions.append("Review error logs for more details")
            
            return {
                "suggestions": suggestions,
                "error_analysis": f"Connection error for {source_type}: {error_message}",
                "next_steps": [
                    "Verify all connection parameters",
                    "Test connection from command line if possible",
                    "Contact your database administrator if issues persist"
                ]
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e)) 