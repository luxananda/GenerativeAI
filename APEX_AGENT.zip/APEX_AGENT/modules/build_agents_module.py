from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from datetime import datetime
import asyncio
import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import os
import requests
from urllib.parse import urlparse
import io
import base64

def setup_build_agents_routes(app, templates):
    """Setup build agents related routes"""

    # Store for agents (in production, use a database)
    langflow_agents = {}
    guided_agents = {}
    studio_agents = {}
    api_agents = {}
    json_agents = {}

    # Initialize Vector Database for context management
    class VectorDatabase:
        def __init__(self):
            self.model = SentenceTransformer('all-MiniLM-L6-v2')  # Fast and efficient embedding model
            self.dimension = 384  # Dimension of the embedding model
            self.index = faiss.IndexFlatIP(self.dimension)  # Inner product for similarity
            self.documents = []  # Store original documents with metadata
            self.context_sources = {}  # Store context source information
            
        def add_documents(self, documents, source_info):
            """Add documents to the vector database"""
            if not documents:
                return []
            
            # Create embeddings
            embeddings = self.model.encode(documents)
            embeddings = embeddings.astype('float32')
            
            # Normalize for cosine similarity (using inner product)
            faiss.normalize_L2(embeddings)
            
            # Add to index
            start_id = len(self.documents)
            self.index.add(embeddings)
            
            # Store documents with metadata
            doc_ids = []
            for i, doc in enumerate(documents):
                doc_id = start_id + i
                self.documents.append({
                    'id': doc_id,
                    'content': doc,
                    'source': source_info['type'],
                    'source_name': source_info.get('name', 'Unknown'),
                    'metadata': source_info
                })
                doc_ids.append(doc_id)
            
            return doc_ids
        
        def search(self, query, top_k=5):
            """Search for similar documents"""
            if self.index.ntotal == 0:
                return []
            
            # Create query embedding
            query_embedding = self.model.encode([query])
            query_embedding = query_embedding.astype('float32')
            faiss.normalize_L2(query_embedding)
            
            # Search
            scores, indices = self.index.search(query_embedding, min(top_k, self.index.ntotal))
            
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if idx >= 0 and idx < len(self.documents):  # Valid index
                    doc = self.documents[idx]
                    results.append({
                        'content': doc['content'],
                        'score': float(score),
                        'source': doc['source'],
                        'source_name': doc['source_name'],
                        'metadata': doc['metadata']
                    })
            
            return results
        
        def get_context_summary(self, query, max_tokens=1000):
            """Get relevant context summary for a query"""
            results = self.search(query, top_k=10)
            
            context_parts = []
            total_tokens = 0
            
            for result in results:
                content = result['content']
                # Rough token estimation (4 chars per token)
                estimated_tokens = len(content) // 4
                
                if total_tokens + estimated_tokens <= max_tokens:
                    context_parts.append(f"[{result['source_name']}]: {content}")
                    total_tokens += estimated_tokens
                else:
                    # Add partial content if space allows
                    remaining_tokens = max_tokens - total_tokens
                    if remaining_tokens > 50:  # Only if meaningful space left
                        partial_content = content[:remaining_tokens * 4]
                        context_parts.append(f"[{result['source_name']}]: {partial_content}...")
                    break
            
            return "\n\n".join(context_parts)

    # Initialize global vector database
    vector_db = VectorDatabase()

    @app.get("/build-agents")
    async def build_agents(request: Request):
        """Build/Add Agents - Create and configure new AI agents"""
        return templates.TemplateResponse("build_agents.html", {"request": request})

    # Langflow Integration APIs
    @app.post("/api/langflow/connect")
    async def connect_langflow(request: Request):
        """Connect to Langflow instance and test connection"""
        try:
            data = await request.json()
            langflow_url = data.get("url", "http://localhost:7860")
            api_key = data.get("api_key", "")
            
            # Simulate connection test
            await asyncio.sleep(1)  # Simulate network delay
            
            return JSONResponse({
                "success": True,
                "message": "Connected to Langflow successfully!",
                "langflow_url": langflow_url,
                "version": "1.0.0"
            })
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.get("/api/langflow/flows")
    async def get_langflow_flows():
        """Get available flows from Langflow"""
        sample_flows = [
            {
                "id": "flow_001",
                "name": "Investment Analysis Agent",
                "description": "Financial investment analysis and research agent",
                "category": "business-analyst",
                "type": "investment-analysis",
                "status": "Ready",
                "created_at": "2024-01-15T10:30:00Z",
                "updated_at": "2024-01-15T14:45:00Z"
            },
            {
                "id": "flow_002", 
                "name": "Data Migration Pipeline",
                "description": "Automated data migration between systems",
                "category": "data-engineering",
                "type": "data-migration",
                "status": "Ready",
                "created_at": "2024-01-14T09:15:00Z",
                "updated_at": "2024-01-14T16:20:00Z"
            },
            {
                "id": "flow_003",
                "name": "Document Processing Agent", 
                "description": "Extract and analyze content from various document types",
                "category": "discovery",
                "type": "document-processor",
                "status": "Ready",
                "created_at": "2024-01-13T11:45:00Z",
                "updated_at": "2024-01-13T13:30:00Z"
            }
        ]
        
        return JSONResponse({"flows": sample_flows})

    @app.post("/api/langflow/import-flow")
    async def import_langflow_flow(request: Request):
        """Import a specific flow from Langflow"""
        try:
            data = await request.json()
            flow_id = data.get("flow_id")
            
            agent_id = f"agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_id,
                "message": f"Flow {flow_id} imported successfully as agent {agent_id}"
            })
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # JSON Import APIs  
    @app.post("/api/agent/import-json")
    async def import_agent_json(request: Request):
        """Import agent from JSON configuration"""
        try:
            data = await request.json()
            json_config = data.get("config", {})
            
            # Validate JSON structure
            required_fields = ["name", "description", "type"]
            for field in required_fields:
                if field not in json_config:
                    return JSONResponse({
                        "success": False, 
                        "error": f"Missing required field: {field}"
                    }, status_code=400)
            
            # Create agent from JSON
            agent_id = f"agent_json_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_id,
                "message": f"Agent '{json_config['name']}' imported successfully from JSON"
            })
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/agent/validate-json")
    async def validate_agent_json(request: Request):
        """Validate agent JSON configuration"""
        try:
            data = await request.json()
            json_config = data.get("config", {})
            
            validation_results = {
                "valid": True,
                "errors": [],
                "warnings": []
            }
            
            # Check required fields
            required_fields = ["name", "description", "type", "category"]
            for field in required_fields:
                if field not in json_config:
                    validation_results["errors"].append(f"Missing required field: {field}")
                    validation_results["valid"] = False
            
            # Check field types
            if "name" in json_config and not isinstance(json_config["name"], str):
                validation_results["errors"].append("Field 'name' must be a string")
                validation_results["valid"] = False
                
            if "timeout" in json_config and not isinstance(json_config["timeout"], int):
                validation_results["warnings"].append("Field 'timeout' should be an integer")
            
            return JSONResponse(validation_results)
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # API Integration
    @app.post("/api/agent/test-api")
    async def test_agent_api(request: Request):
        """Test API endpoint connection for agent integration"""
        import httpx
        import time
        
        try:
            data = await request.json()
            endpoint = data.get("endpoint")
            method = data.get("method", "POST")
            headers = data.get("headers", {"Content-Type": "application/json"})
            test_payload = data.get("payload", {
                "inputs": {
                    "input_value": "hello world!"
                },
                "tweaks": {},
                "clear_cache": False
            })
            
            if not endpoint:
                return JSONResponse({
                    "success": False,
                    "error": "No endpoint provided"
                }, status_code=400)
            
            # Validate URL format
            if not endpoint.startswith(('http://', 'https://')):
                return JSONResponse({
                    "success": False,
                    "error": "Invalid URL format. Must start with http:// or https://"
                }, status_code=400)
            
            start_time = time.time()
            
            # Make actual API request with timeout
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.request(
                    method=method,
                    url=endpoint,
                    headers=headers,
                    json=test_payload
                )
                
                response_time = round((time.time() - start_time) * 1000, 2)
                
                # Check if response is successful
                if response.status_code < 400:
                    return JSONResponse({
                        "success": True,
                        "status_code": response.status_code,
                        "response_time": f"{response_time}ms",
                        "message": f"✅ API endpoint is reachable and responded successfully!",
                        "response_preview": response.text[:200] + "..." if len(response.text) > 200 else response.text
                    })
                else:
                    return JSONResponse({
                        "success": False,
                        "status_code": response.status_code,
                        "response_time": f"{response_time}ms",
                        "error": f"API returned status {response.status_code}. This might be expected depending on your API requirements.",
                        "response_preview": response.text[:200] + "..." if len(response.text) > 200 else response.text
                    })
                    
        except httpx.TimeoutException:
            return JSONResponse({
                "success": False,
                "error": "Request timed out. The API endpoint took too long to respond (>10 seconds)."
            }, status_code=408)
        except httpx.ConnectError:
            return JSONResponse({
                "success": False,
                "error": "Could not connect to the API endpoint. Please check the URL and ensure the service is running."
            }, status_code=503)
        except Exception as e:
            return JSONResponse({
                "success": False,
                "error": f"Error testing API: {str(e)}"
            }, status_code=500)

    @app.post("/api/agent/save-api-agent")
    async def save_api_agent(request: Request):
        """Save API agent as draft"""
        try:
            data = await request.json()
            
            agent_config = {
                "id": f"api_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data.get("name", "API Agent"),
                "category": data.get("category", "general"),
                "description": data.get("description", ""),
                "type": "direct-api",
                "endpoint": data.get("endpoint"),
                "inputType": data.get("inputType", "chat"),
                "outputType": data.get("outputType", "chat"),
                "testInput": data.get("testInput", "hello world!"),
                "humanInLoop": data.get("humanInLoop", True),
                "status": "draft",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            api_agents[agent_config["id"]] = agent_config
            
            print(f"💾 API Agent saved: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"💾 Studio agent '{agent_config['name']}' saved successfully!",
                "agent": agent_config
            })
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/agent/create-api-agent")
    async def create_api_agent(request: Request):
        """Create and deploy agent with direct API integration"""
        try:
            data = await request.json()
            
            agent_config = {
                "id": f"api_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data.get("name", "API Agent"),
                "category": data.get("category", "general"),
                "description": data.get("description", ""),
                "type": "direct-api",
                "endpoint": data.get("endpoint"),
                "inputType": data.get("inputType", "chat"),
                "outputType": data.get("outputType", "chat"),
                "testInput": data.get("testInput", "hello world!"),
                "humanInLoop": data.get("humanInLoop", True),
                "status": "active",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            api_agents[agent_config["id"]] = agent_config
            
            print(f"🚀 API Agent created and deployed: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🚀 API agent '{agent_config['name']}' created and deployed successfully!",
                "agent": agent_config
            })
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # JSON Agent Testing API
    @app.post("/api/agent/test-json")
    async def test_agent_json(request: Request):
        """Test JSON configuration for agent deployment"""
        try:
            data = await request.json()
            config = data.get("config", {})
            
            if not config:
                return JSONResponse({
                    "success": False,
                    "error": "No JSON configuration provided"
                }, status_code=400)
            
            # Validate JSON structure for Langflow
            validation_results = []
            
            # Check for essential Langflow fields
            if "data" in config:
                validation_results.append("✅ Found 'data' section (Langflow flow definition)")
            if "nodes" in config.get("data", {}):
                nodes = config["data"]["nodes"]
                validation_results.append(f"✅ Found {len(nodes)} nodes in flow")
            if "edges" in config.get("data", {}):
                edges = config["data"]["edges"]
                validation_results.append(f"✅ Found {len(edges)} edges connecting nodes")
            
            # Check for flow metadata
            if "name" in config:
                validation_results.append(f"✅ Flow name: '{config['name']}'")
            if "description" in config:
                validation_results.append(f"✅ Flow description provided")
            if "id" in config:
                validation_results.append(f"✅ Flow ID: {config['id']}")
            
            # Try to extract flow ID for endpoint generation
            flow_id = config.get("id", "unknown")
            if flow_id != "unknown":
                potential_endpoint = f"http://localhost:7860/api/v1/run/{flow_id}"
                validation_results.append(f"🔗 Potential API endpoint: {potential_endpoint}")
            
            details = "\n".join(validation_results) if validation_results else "Basic JSON structure validated"
            
            return JSONResponse({
                "success": True,
                "message": "JSON configuration validated successfully",
                "details": details,
                "flow_id": flow_id,
                "node_count": len(config.get("data", {}).get("nodes", [])),
                "edge_count": len(config.get("data", {}).get("edges", []))
            })
            
        except json.JSONDecodeError:
            return JSONResponse({
                "success": False,
                "error": "Invalid JSON format"
            }, status_code=400)
        except Exception as e:
            return JSONResponse({
                "success": False,
                "error": f"JSON validation failed: {str(e)}"
            }, status_code=500)

    # Comprehensive Agent Creation API
    @app.post("/api/agent/create")
    async def create_comprehensive_agent(request: Request):
        """Create agent with full configuration including human-in-the-loop"""
        try:
            data = await request.json()
            
            # Validate required fields
            required_fields = ["name", "description", "category", "type"]
            for field in required_fields:
                if field not in data:
                    return JSONResponse({
                        "success": False, 
                        "error": f"Missing required field: {field}"
                    }, status_code=400)
            
            # Create comprehensive agent configuration
            agent_config = {
                "id": f"agent_{data['category']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data["name"],
                "description": data["description"],
                "category": data["category"],
                "subCategory": data.get("subCategory", ""),
                "type": data["type"],
                "endpoint": data.get("endpoint", ""),  # Store API endpoint for API agents
                "method": data.get("method", "POST"),  # Store HTTP method
                "config": data.get("config", {}),  # Store JSON config for JSON agents
                "priority": data.get("priority", "medium"),
                "environment": data.get("environment", "development"),
                "schedule": data.get("schedule", "manual"),
                "timeout": data.get("timeout", 60),
                "human_in_loop": {
                    "enabled": data.get("humanInLoop", {}).get("enabled", True),
                    "validation_points": data.get("humanInLoop", {}).get("validationPoints", []),
                    "notification_email": data.get("humanInLoop", {}).get("notificationEmail", ""),
                    "escalation_timeout": data.get("humanInLoop", {}).get("escalationTimeout", 30)
                },
                "status": "created",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            # For JSON agents, try to extract endpoint from config
            if data.get("type") == "json-integration" and data.get("config", {}):
                config = data["config"]
                flow_id = config.get("id")
                if flow_id:
                    agent_config["endpoint"] = f"http://localhost:7860/api/v1/run/{flow_id}"
                    agent_config["flow_id"] = flow_id
            
            # Store the agent in the appropriate store based on type
            if data.get("category") == "api-integration" or data.get("type") == "api-integration":
                api_agents[agent_config["id"]] = agent_config
            elif data.get("category") == "json-integration" or data.get("type") == "json-integration":
                json_agents[agent_config["id"]] = agent_config
            elif data.get("category") == "studio" or data.get("type") == "studio":
                studio_agents[agent_config["id"]] = agent_config
            elif data.get("category") == "guided" or data.get("type") == "guided":
                guided_agents[agent_config["id"]] = agent_config
            else:
                # Default to guided agents for other types
                guided_agents[agent_config["id"]] = agent_config
            
            print(f"✅ Agent created: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🎉 Agent '{agent_config['name']}' has been created successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # Agent Type Information APIs
    @app.get("/api/agent/types/{category}")
    async def get_agent_types_by_category(category: str):
        """Get available agent types for a specific category"""
        
        agent_types = {
            "discovery": [
                {"id": "url-search", "name": "URL Search Agent", "description": "Search and analyze content from URLs and websites"},
                {"id": "pdf-analyzer", "name": "PDF Analyzer Agent", "description": "Extract and analyze content from PDF documents"},
                {"id": "document-processor", "name": "Document Processor", "description": "Process Word docs, Excel files, and text documents"},
                {"id": "presentation-analyzer", "name": "Presentation Analyzer", "description": "Analyze PowerPoint and presentation files"},
                {"id": "metadata-extractor", "name": "Metadata Extractor", "description": "Extract and organize metadata from various sources"},
                {"id": "content-synthesizer", "name": "Content Synthesizer", "description": "Build topical summaries and knowledge bases"}
            ],
            "business-analyst": [
                {"id": "requirements-agent", "name": "Requirements Agent", "description": "Gather, analyze and document business requirements"},
                {"id": "impact-analysis", "name": "Impact Analysis Agent", "description": "Assess business impact and change implications"},
                {"id": "mapping-agent", "name": "Mapping Agent", "description": "Create process maps and workflow diagrams"},
                {"id": "brd-agent", "name": "BRD Agent", "description": "Generate Business Requirements Documents"},
                {"id": "frd-agent", "name": "FRD Agent", "description": "Create Functional Requirements Documents"}
            ],
            "data-engineering": [
                # Data Onboarding
                {"id": "data-migration", "name": "Migration Agent", "description": "Migrate data between systems", "subcategory": "onboarding"},
                {"id": "data-cleaning", "name": "Cleaning Agent", "description": "Clean and prepare data", "subcategory": "onboarding"},
                {"id": "data-modeling", "name": "Modeling Agent", "description": "Create data models", "subcategory": "onboarding"},
                {"id": "data-integration", "name": "Integration Agent", "description": "Integrate multiple sources", "subcategory": "onboarding"},
                # Data Pipeline  
                {"id": "ddk-agent", "name": "DDK Agent", "description": "Data Development Kit automation", "subcategory": "pipeline"},
                {"id": "enterprise-data-service", "name": "Enterprise Data Service", "description": "Enterprise data layer management", "subcategory": "pipeline"},
                {"id": "api-agent", "name": "API Agent", "description": "API data integration", "subcategory": "pipeline"},
                {"id": "bulk-data-agent", "name": "Bulk Data Agent", "description": "Large-scale data processing", "subcategory": "pipeline"},
                # Data Orchestrator
                {"id": "data-orchestrator", "name": "Data Orchestrator", "description": "Orchestrate complex workflows", "subcategory": "orchestrator"},
                {"id": "data-scheduler", "name": "Data Scheduler", "description": "Schedule and manage jobs", "subcategory": "orchestrator"},
                {"id": "workflow-monitor", "name": "Workflow Monitor", "description": "Monitor pipeline health", "subcategory": "orchestrator"},
                # Data Storage
                {"id": "crud-script-agent", "name": "CRUD Script Agent", "description": "Auto-generate insert/update/delete scripts", "subcategory": "storage"},
                {"id": "schema-manager", "name": "Schema Manager", "description": "Manage database schemas", "subcategory": "storage"},
                {"id": "backup-agent", "name": "Backup Agent", "description": "Automated backup and recovery", "subcategory": "storage"}
            ],
            "conversational": [
                {"id": "multi-agent-chat", "name": "Multi-Agent Chat", "description": "Intelligent routing between multiple agents"},
                {"id": "customer-support", "name": "Customer Support Chat", "description": "Automated customer service interactions"},
                {"id": "knowledge-assistant", "name": "Knowledge Assistant", "description": "Question-answering from knowledge base"}
            ],
            "testing": [
                {"id": "unit-testing", "name": "Unit Testing Agent", "description": "Automated unit test generation and execution"},
                {"id": "integration-testing", "name": "Integration Testing Agent", "description": "End-to-end integration testing"},
                {"id": "performance-testing", "name": "Performance Testing Agent", "description": "Load and performance testing automation"},
                {"id": "security-testing", "name": "Security Testing Agent", "description": "Security vulnerability assessment"}
            ],
            "production-support": [
                {"id": "incident-response", "name": "Incident Response Agent", "description": "Automated incident detection and response"},
                {"id": "monitoring-agent", "name": "Monitoring Agent", "description": "System health monitoring and alerting"},
                {"id": "log-analysis", "name": "Log Analysis Agent", "description": "Automated log parsing and analysis"},
                {"id": "troubleshooting", "name": "Troubleshooting Agent", "description": "Automated issue diagnosis and resolution"}
            ],
            "devops": [
                {"id": "ci-cd-agent", "name": "CI/CD Agent", "description": "Continuous integration and deployment automation"},
                {"id": "infrastructure-agent", "name": "Infrastructure Agent", "description": "Infrastructure as code management"},
                {"id": "deployment-agent", "name": "Deployment Agent", "description": "Automated application deployment"},
                {"id": "container-agent", "name": "Container Agent", "description": "Docker and Kubernetes management"}
            ],
            "operations": [
                {"id": "workflow-automation", "name": "Workflow Automation Agent", "description": "Business process automation"},
                {"id": "resource-optimization", "name": "Resource Optimization Agent", "description": "Resource allocation optimization"},
                {"id": "scheduling-agent", "name": "Scheduling Agent", "description": "Task and resource scheduling"},
                {"id": "compliance-agent", "name": "Compliance Agent", "description": "Regulatory compliance monitoring"}
            ],
            "business-management": [
                {"id": "strategy-agent", "name": "Strategy Agent", "description": "Business strategy analysis and planning"},
                {"id": "decision-support", "name": "Decision Support Agent", "description": "Data-driven decision making support"},
                {"id": "risk-management", "name": "Risk Management Agent", "description": "Risk assessment and mitigation"},
                {"id": "performance-metrics", "name": "Performance Metrics Agent", "description": "KPI tracking and analysis"}
            ],
            "data-copilots": [
                {"id": "data-analyst", "name": "Data Analyst Copilot", "description": "AI-powered data analysis assistant"},
                {"id": "sql-copilot", "name": "SQL Copilot", "description": "Intelligent SQL query generation and optimization"},
                {"id": "visualization-copilot", "name": "Visualization Copilot", "description": "Automated chart and dashboard creation"},
                {"id": "reporting-copilot", "name": "Reporting Copilot", "description": "Automated report generation and insights"}
            ]
        }
        
        if category not in agent_types:
            raise HTTPException(status_code=404, detail="Category not found")
        
        return JSONResponse({"category": category, "types": agent_types[category]})

    # Human-in-the-Loop Management
    @app.post("/api/agent/human-loop/validate")
    async def request_human_validation(request: Request):
        """Request human validation for agent action"""
        try:
            data = await request.json()
            
            validation_request = {
                "id": f"validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "agent_id": data.get("agent_id"),
                "validation_type": data.get("validation_type"),
                "content": data.get("content"),
                "priority": data.get("priority", "medium"),
                "created_at": datetime.now().isoformat(),
                "status": "pending"
            }
            
            print(f"🔔 Human validation requested: {validation_request['validation_type']} for agent {validation_request['agent_id']}")
            
            return JSONResponse({
                "success": True,
                "validation_id": validation_request["id"],
                "message": "Validation request submitted. You will be notified when human review is needed."
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # API Integration for Langflow
    @app.post("/api/agent/test-langflow-api")
    async def test_langflow_api(request: Request):
        """Test Langflow API endpoint with specific format"""
        try:
            data = await request.json()
            endpoint = data.get("endpoint")
            input_value = data.get("input_value", "hello world!")
            output_type = data.get("output_type", "chat")
            input_type = data.get("input_type", "chat")
            
            if not endpoint:
                return JSONResponse({"success": False, "error": "Endpoint is required"}, status_code=400)
            
            # Simulate API testing with Langflow format
            import time
            start_time = time.time()
            
            payload = {
                "input_value": input_value,
                "output_type": output_type,
                "input_type": input_type
            }
            
            await asyncio.sleep(1)  # Simulate network delay
            
            # Mock successful response
            mock_response = {
                "outputs": [
                    {
                        "inputs": {"input_value": input_value},
                        "outputs": [
                            {
                                "results": {
                                    "message": {
                                        "data": f"Response from Langflow: {input_value}"
                                    }
                                }
                            }
                        ]
                    }
                ]
            }
            
            response_time = f"{int((time.time() - start_time) * 1000)}ms"
            
            return JSONResponse({
                "success": True,
                "status_code": 200,
                "response_time": response_time,
                "api_response": str(mock_response),
                "message": "Langflow API endpoint is reachable and responding correctly"
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/agent/create-langflow-api-agent")
    async def create_langflow_api_agent(request: Request):
        """Create agent with Langflow API integration"""
        try:
            data = await request.json()
            
            agent_config = {
                "id": f"langflow_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data.get("name", "Langflow API Agent"),
                "description": f"Langflow API agent connected to {data.get('endpoint', 'N/A')}",
                "category": data.get("category", "api-integration"),
                "type": data.get("type", "langflow-api"),
                "endpoint": data.get("endpoint"),
                "output_type": data.get("output_type", "chat"),
                "input_type": data.get("input_type", "chat"),
                "status": "active",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            langflow_agents[agent_config["id"]] = agent_config
            
            print(f"✅ Langflow API Agent created: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🎉 Langflow API agent '{agent_config['name']}' created successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # Enhanced Agent Builder APIs
    @app.post("/api/agent/create-guided")
    async def create_guided_agent(request: Request):
        """Create agent using guided builder"""
        try:
            data = await request.json()
            
            agent_config = {
                "id": f"guided_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data.get("name", "Guided Agent"),
                "description": data.get("description", ""),
                "topic": data.get("topic"),
                "topicName": data.get("topicName"),
                "capabilities": data.get("capabilities", []),
                "responseStyle": data.get("responseStyle", "professional"),
                "detailLevel": data.get("detailLevel", "detailed"),
                "humanInLoop": data.get("humanInLoop", True),
                "model": data.get("model", "gpt-4"),
                "creativity": data.get("creativity", 50),
                "instructions": data.get("instructions", ""),
                "type": "guided",
                "category": data.get("category", "general"),
                "status": "active",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            guided_agents[agent_config["id"]] = agent_config
            
            print(f"✅ Guided Agent created: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🎉 Guided agent '{agent_config['name']}' created successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/agent/save-studio")
    async def save_studio_agent(request: Request):
        """Save agent from studio builder"""
        try:
            data = await request.json()
            
            agent_id = data.get("id") or f"studio_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            agent_config = {
                "id": agent_id,
                "name": data.get("name", "Studio Agent"),
                "category": data.get("category", "general"),
                "role": data.get("role", ""),
                "skills": data.get("skills", ""),
                "guidelines": data.get("guidelines", ""),
                "variables": data.get("variables", []),
                "knowledge": data.get("knowledge", []),
                "tools": data.get("tools", []),
                "type": "studio",
                "status": "draft",
                "created_at": datetime.now().isoformat() if not data.get("id") else None,
                "updated_at": datetime.now().isoformat()
            }
            
            # Remove None values
            agent_config = {k: v for k, v in agent_config.items() if v is not None}
            
            studio_agents[agent_config["id"]] = agent_config
            
            print(f"💾 Studio Agent saved: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"💾 Studio agent '{agent_config['name']}' saved successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/agent/deploy-studio")
    async def deploy_studio_agent(request: Request):
        """Deploy agent from studio builder"""
        try:
            data = await request.json()
            
            agent_id = data.get("id") or f"studio_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            agent_config = {
                "id": agent_id,
                "name": data.get("name", "Studio Agent"),
                "category": data.get("category", "general"),
                "role": data.get("role", ""),
                "skills": data.get("skills", ""),
                "guidelines": data.get("guidelines", ""),
                "variables": data.get("variables", []),
                "knowledge": data.get("knowledge", []),
                "tools": data.get("tools", []),
                "type": "studio",
                "status": "active",
                "created_at": datetime.now().isoformat() if not data.get("id") else None,
                "updated_at": datetime.now().isoformat()
            }
            
            # Remove None values
            agent_config = {k: v for k, v in agent_config.items() if v is not None}
            
            studio_agents[agent_config["id"]] = agent_config
            
            print(f"🚀 Studio Agent deployed: {agent_config['name']} ({agent_config['id']})")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🚀 Studio agent '{agent_config['name']}' deployed successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # Agent template library endpoints
    @app.post("/api/agent/save-template")
    async def save_agent_template(request: Request):
        """Save agent configuration as reusable template"""
        try:
            data = await request.json()
            
            # Create template ID
            template_id = f"template_{data['category']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Store template (in production, use a database)
            template_config = {
                "id": template_id,
                "name": data.get("name"),
                "category": data.get("category"),
                "subCategory": data.get("subCategory"),
                "template_data": data,
                "created_at": datetime.now().isoformat(),
                "type": "template"
            }
            
            # You could store this in a templates dictionary or database
            # For now, we'll just return success
            print(f"✅ Template saved: {template_config['name']} ({template_id})")
            
            return JSONResponse({
                "success": True,
                "message": f"Template '{data.get('name')}' saved successfully",
                "template_id": template_id
            })
            
        except Exception as e:
            return JSONResponse({
                "success": False,
                "error": str(e)
            }, status_code=500)

    @app.post("/api/agent/create-library")
    async def create_agent_from_library(request: Request):
        """Create and deploy agent from comprehensive library configuration"""
        try:
            data = await request.json()
            
            # Create comprehensive agent configuration
            agent_config = {
                "id": f"agent_{data['category']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "name": data["name"],
                "description": data["description"],
                "category": data["category"],
                "subCategory": data.get("subCategory"),
                "type": "library-agent",
                "version": data.get("version", "1.0.0"),
                "tags": data.get("tags", "").split(",") if data.get("tags") else [],
                "priority": data.get("priorityLevel", "medium"),
                "human_in_loop": data.get("humanInLoop", True),
                "enable_logging": data.get("enableLogging", True),
                
                # Role & Purpose
                "role_title": data.get("roleTitle"),
                "role_description": data.get("roleDescription"),
                "expertise_level": data.get("expertiseLevel", "advanced"),
                "primary_purpose": data.get("primaryPurpose"),
                "key_objectives": data.get("keyObjectives"),
                "success_metrics": data.get("successMetrics"),
                
                # Skills & Capabilities
                "domain_expertise": data.get("domainExpertise"),
                "technical_skills": data.get("technicalSkills"),
                "analytical_methods": data.get("analyticalMethods"),
                "preferred_tools": data.get("preferredTools"),
                "api_integrations": data.get("apiIntegrations"),
                "data_sources": data.get("dataSources"),
                
                # Prompts & Templates
                "system_prompt": data.get("systemPrompt"),
                "welcome_message": data.get("welcomeMessage"),
                "context_instructions": data.get("contextInstructions"),
                
                # Response Guidelines
                "response_style": data.get("responseStyle", "professional"),
                "detail_level": data.get("detailLevel", "detailed"),
                "language_tone": data.get("languageTone", "neutral"),
                
                # Performance Configuration
                "model_selection": data.get("modelSelection", "gpt-4"),
                "fallback_model": data.get("fallbackModel"),
                "temperature": float(data.get("temperature", 0.7)),
                "max_tokens": int(data.get("maxTokens", 2048)),
                "caching_strategy": data.get("cachingStrategy", "aggressive"),
                "rate_limiting": data.get("rateLimiting", "standard"),
                
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            
            # Store the agent in appropriate dictionary based on type and category
            agent_type = data.get("type", "library-agent")
            category = data.get("category", "")
            from_studio = data.get("fromStudio", False)
            
            if agent_type == "studio-agent" or from_studio:
                studio_agents[agent_config["id"]] = agent_config
            elif "business-analyst" in category:
                guided_agents[agent_config["id"]] = agent_config
            elif "data-engineering" in category:
                guided_agents[agent_config["id"]] = agent_config
            else:
                # Default to guided agents for library-created agents
                guided_agents[agent_config["id"]] = agent_config
            
            print(f"✅ Library Agent created: {agent_config['name']} ({agent_config['id']})")
            print(f"   Category: {agent_config['category']} > {agent_config.get('subCategory', 'N/A')}")
            print(f"   Type: {agent_config['type']}")
            
            return JSONResponse({
                "success": True,
                "agent_id": agent_config["id"],
                "message": f"🎉 Agent '{agent_config['name']}' created and deployed successfully!",
                "agent": agent_config
            })
            
        except Exception as e:
            return JSONResponse({
                "success": False,
                "error": str(e)
            }, status_code=500)

    @app.post("/api/agent/auto-populate")
    async def auto_populate_agent_configuration(request: Request):
        """Auto-populate agent configuration based on category and sub-category using AI"""
        try:
            data = await request.json()
            category = data.get("category", "")
            sub_category = data.get("subCategory", "")
            
            # AI-generated content templates based on category and sub-category
            templates = {
                "business-analyst": {
                    "requirement": {
                        "roleTitle": "Senior Business Requirements Analyst",
                        "roleDescription": "Expert in gathering, analyzing, and documenting business requirements with stakeholder alignment",
                        "primaryPurpose": "Facilitate comprehensive requirements gathering and analysis to bridge business needs with technical solutions",
                        "keyObjectives": "• Elicit and document functional/non-functional requirements\n• Ensure stakeholder alignment and buy-in\n• Create clear, testable acceptance criteria\n• Manage requirements traceability throughout project lifecycle",
                        "successMetrics": "• Requirements completion rate (>95%)\n• Stakeholder satisfaction scores (>4.5/5)\n• Defect reduction due to clear requirements (>80%)\n• Time-to-approval for requirements documents (<3 days)",
                        "domainExpertise": "Requirements Engineering, Stakeholder Management, Business Process Analysis, User Story Development",
                        "technicalSkills": "JIRA, Confluence, Visio, Requirements Management Tools, User Story Mapping, Acceptance Criteria Writing",
                        "analyticalMethods": "GAP Analysis, As-Is/To-Be Process Mapping, Use Case Analysis, Requirements Prioritization (MoSCoW)",
                        "preferredTools": "JIRA, Confluence, Miro, Lucidchart, Azure DevOps, Requirements Traceability Matrix",
                        "systemPrompt": "You are a Senior Business Requirements Analyst with expertise in gathering, analyzing, and documenting business requirements. Your approach is systematic, stakeholder-focused, and detail-oriented. Always ensure requirements are SMART (Specific, Measurable, Achievable, Relevant, Time-bound) and include proper acceptance criteria.",
                        "welcomeMessage": "Hello! I'm your Business Requirements Analyst. I specialize in helping you capture, analyze, and document comprehensive business requirements. Whether you need help with user stories, acceptance criteria, or stakeholder alignment, I'm here to ensure your requirements are clear, complete, and actionable. What requirements challenge can I help you with today?",
                        "contextInstructions": "Always ask clarifying questions to understand the full business context. Focus on the 'why' behind requirements, not just the 'what'. Consider impacts on all stakeholders and downstream processes."
                    },
                    "mapping": {
                        "roleTitle": "Business Process Mapping Specialist",
                        "roleDescription": "Expert in documenting and optimizing business processes through detailed process mapping and analysis",
                        "primaryPurpose": "Create comprehensive process maps and workflows to identify improvement opportunities and ensure process clarity",
                        "keyObjectives": "• Document current state (As-Is) processes\n• Design future state (To-Be) processes\n• Identify process inefficiencies and bottlenecks\n• Facilitate process standardization across teams",
                        "successMetrics": "• Process documentation accuracy (>98%)\n• Process efficiency improvements (>25%)\n• Stakeholder process understanding (>90%)\n• Process standardization adoption rate (>85%)",
                        "domainExpertise": "Business Process Mapping, Workflow Analysis, Process Optimization, Change Management",
                        "technicalSkills": "BPMN 2.0, Visio, Lucidchart, Process Mining Tools, Value Stream Mapping, Lean Six Sigma",
                        "analyticalMethods": "Process Flow Analysis, Value Stream Mapping, Root Cause Analysis, Time and Motion Studies",
                        "preferredTools": "Visio, Lucidchart, Miro, Bizagi, ARIS, ProcessOn, Draw.io",
                        "systemPrompt": "You are a Business Process Mapping Specialist with deep expertise in documenting and analyzing business processes. Use BPMN standards where appropriate and always consider process efficiency, compliance, and user experience in your recommendations.",
                        "welcomeMessage": "Hi there! I'm your Business Process Mapping expert. I help organizations visualize, document, and optimize their business processes. Whether you need As-Is process documentation, To-Be process design, or process improvement recommendations, I'm here to help you create clear, actionable process maps. What process would you like to work on today?",
                        "contextInstructions": "Always start by understanding the process scope, stakeholders, and current pain points. Focus on creating clear, standardized process documentation that can be easily understood and followed by all team members."
                    }
                },
                "data-engineering": {
                    "pipeline": {
                        "roleTitle": "Senior Data Pipeline Engineer",
                        "roleDescription": "Expert in designing, building, and maintaining scalable data pipelines and ETL/ELT processes",
                        "primaryPurpose": "Architect and implement robust data pipelines that ensure reliable, efficient, and scalable data processing",
                        "keyObjectives": "• Design scalable data architectures\n• Implement reliable ETL/ELT processes\n• Ensure data quality and governance\n• Optimize pipeline performance and cost",
                        "successMetrics": "• Pipeline uptime (>99.9%)\n• Data processing latency (<15 minutes)\n• Data quality scores (>98%)\n• Cost optimization (>30% reduction)",
                        "domainExpertise": "Data Architecture, ETL/ELT Design, Stream Processing, Data Warehousing, Cloud Platforms",
                        "technicalSkills": "Apache Airflow, Spark, Kafka, Python, SQL, Docker, Kubernetes, AWS/Azure/GCP",
                        "analyticalMethods": "Data Flow Analysis, Performance Profiling, Cost-Benefit Analysis, Data Lineage Tracking",
                        "preferredTools": "Apache Airflow, Apache Spark, Kafka, dbt, Snowflake, BigQuery, Databricks",
                        "systemPrompt": "You are a Senior Data Pipeline Engineer with expertise in building enterprise-scale data pipelines. Focus on scalability, reliability, and maintainability. Always consider data governance, security, and cost optimization in your solutions.",
                        "welcomeMessage": "Hello! I'm your Data Pipeline Engineering expert. I specialize in designing and building robust, scalable data pipelines that power analytics and ML workflows. Whether you need help with ETL design, stream processing, or pipeline optimization, I'm here to help you build reliable data infrastructure. What data pipeline challenge can I assist you with?",
                        "contextInstructions": "Always consider data volume, velocity, variety, and veracity. Focus on building maintainable, monitorable pipelines with proper error handling and data quality checks."
                    }
                }
            }
            
            # Get the appropriate template
            template = {}
            if category in templates and sub_category in templates[category]:
                template = templates[category][sub_category]
            else:
                # Default template for any category/subcategory
                template = {
                    "roleTitle": f"Senior {category.replace('-', ' ').title()} Specialist",
                    "roleDescription": f"Expert in {category.replace('-', ' ')} with focus on {sub_category}",
                    "primaryPurpose": f"Provide comprehensive {category.replace('-', ' ')} guidance and solutions",
                    "keyObjectives": f"• Deliver high-quality {category.replace('-', ' ')} solutions\n• Ensure best practices and standards compliance\n• Provide expert guidance and recommendations\n• Optimize processes and outcomes",
                    "successMetrics": "• Solution effectiveness (>90%)\n• Client satisfaction (>4.5/5)\n• Process improvement (>25%)\n• Delivery timeline adherence (>95%)",
                    "domainExpertise": f"{category.replace('-', ' ').title()}, {sub_category.title()}, Best Practices, Industry Standards",
                    "technicalSkills": "Domain-specific tools, Analysis frameworks, Documentation, Stakeholder management",
                    "analyticalMethods": "Requirements analysis, Gap analysis, Solution design, Performance measurement",
                    "preferredTools": "Industry-standard tools, Collaboration platforms, Documentation systems",
                    "systemPrompt": f"You are a {category.replace('-', ' ')} expert specializing in {sub_category}. Provide comprehensive, actionable guidance based on industry best practices and proven methodologies.",
                    "welcomeMessage": f"Hello! I'm your {category.replace('-', ' ')} specialist focusing on {sub_category}. I'm here to provide expert guidance and practical solutions. How can I help you today?",
                    "contextInstructions": "Always provide context-aware recommendations based on industry best practices and current standards."
                }
            
            print(f"✅ Auto-populated configuration for {category} > {sub_category}")
            return JSONResponse({
                "success": True,
                "configuration": template,
                "message": f"Configuration auto-populated for {category} > {sub_category}"
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/context/process")
    async def process_context_sources(request: Request):
        """Process and route context sources to appropriate systems"""
        try:
            data = await request.json()
            context_sources = data.get("contextSources", [])
            processing_type = data.get("type", "discovery")  # discovery or agent-building
            
            processed_contexts = []
            
            for context in context_sources:
                context_type = context.get("type")
                context_config = context.get("config", {})
                
                # Route to appropriate processing system based on context type
                if context_type == "code":
                    result = await process_code_context(context_config)
                elif context_type == "url":
                    result = await process_url_context(context_config)
                elif context_type == "document":
                    result = await process_document_context(context_config)
                elif context_type == "external":
                    result = await process_external_context(context_config)
                elif context_type == "semantic":
                    result = await process_semantic_context(context_config)
                elif context_type == "application":
                    result = await process_application_context(context_config)
                else:
                    result = {"status": "unsupported", "message": f"Context type '{context_type}' not supported"}
                
                processed_contexts.append({
                    "id": context.get("id"),
                    "type": context_type,
                    "result": result
                })
            
            return JSONResponse({
                "success": True,
                "processed_contexts": processed_contexts,
                "message": f"Processed {len(processed_contexts)} context sources"
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    async def process_code_context(config):
        """Process code repository context"""
        try:
            documents = []
            
            # Simulate code processing (in production, integrate with GitHub API, file system, etc.)
            code_content = config.get('content', '')
            if code_content:
                # Split code into meaningful chunks (functions, classes, etc.)
                code_chunks = split_code_content(code_content)
                documents.extend(code_chunks)
            else:
                # Default code examples for demo
                documents = [
                    "def process_data(df): return df.groupby('category').sum()",
                    "class DataProcessor: def __init__(self): self.data = []",
                    "import pandas as pd\nimport numpy as np\n# Data analysis utilities",
                    "async def fetch_api_data(url): response = await httpx.get(url)"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'code',
                'name': config.get('name', 'Code Repository'),
                'language': config.get('language', 'python'),
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"Code repository processed: {len(documents)} code chunks indexed",
                "insights": ["Function definitions extracted", "Code patterns indexed", "Available for semantic search"],
                "vector_embeddings": f"Added {len(doc_ids)} code embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error",
                "summary": f"Error processing code: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    async def process_url_context(config):
        """Process URL/web content context"""
        try:
            documents = []
            url = config.get('url', '')
            
            if url:
                # In production, implement actual web scraping
                try:
                    response = requests.get(url, timeout=10)
                    if response.status_code == 200:
                        # Simple text extraction (in production, use BeautifulSoup, etc.)
                        content = response.text[:5000]  # Limit content
                        documents = split_text_content(content, max_chunk_size=500)
                    else:
                        documents = [f"Unable to fetch content from {url} (Status: {response.status_code})"]
                except Exception as e:
                    documents = [f"Error fetching {url}: {str(e)}"]
            else:
                # Demo content
                documents = [
                    "Enterprise data governance policies and procedures for financial institutions",
                    "Best practices for API security and authentication in cloud environments",
                    "Machine learning model deployment strategies for production systems",
                    "Regulatory compliance requirements for data processing and storage"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'url',
                'name': config.get('name', f'Web Content: {url}'),
                'url': url,
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"Web content processed: {len(documents)} text chunks indexed",
                "insights": ["Content extracted and chunked", "Text embeddings created", "Available for semantic search"],
                "vector_embeddings": f"Added {len(doc_ids)} content embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error",
                "summary": f"Error processing URL: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    async def process_document_context(config):
        """Process document context (PDF, Word, Excel, etc.)"""
        try:
            documents = []
            file_content = config.get('content', '')
            file_name = config.get('name', 'document')
            
            if file_content:
                # In production, implement actual document parsing (PyPDF2, python-docx, etc.)
                # For now, simulate document processing
                if file_name.endswith('.pdf'):
                    documents = simulate_pdf_content()
                elif file_name.endswith(('.doc', '.docx')):
                    documents = simulate_word_content()
                elif file_name.endswith(('.xls', '.xlsx')):
                    documents = simulate_excel_content()
                else:
                    documents = split_text_content(file_content, max_chunk_size=500)
            else:
                # Demo document content
                documents = [
                    "Financial risk assessment methodology for investment portfolios",
                    "Quarterly earnings report showing 15% growth in revenue",
                    "Data privacy policy compliance checklist for GDPR requirements",
                    "Technical architecture documentation for microservices deployment",
                    "Business requirements document for customer onboarding process"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'document',
                'name': config.get('name', 'Document'),
                'file_type': get_file_type(file_name),
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"Document processed: {len(documents)} sections indexed",
                "insights": ["Text extracted and segmented", "Document structure analyzed", "Content available for search"],
                "vector_embeddings": f"Added {len(doc_ids)} document embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error",
                "summary": f"Error processing document: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    async def process_external_context(config):
        """Process external API/web scraping context"""
        try:
            documents = []
            api_endpoint = config.get('endpoint', '')
            
            if api_endpoint:
                # In production, implement actual API integration
                try:
                    # Simulate API call
                    if 'github' in api_endpoint.lower():
                        documents = simulate_github_api_content()
                    elif 'confluence' in api_endpoint.lower():
                        documents = simulate_confluence_content()
                    else:
                        documents = simulate_generic_api_content()
                except Exception as e:
                    documents = [f"Error accessing API {api_endpoint}: {str(e)}"]
            else:
                # Demo external content
                documents = [
                    "API Documentation: RESTful endpoints for customer data management",
                    "Integration Guide: Step-by-step process for third-party system connectivity",
                    "Rate Limiting Policy: Maximum 1000 requests per hour per API key",
                    "Authentication Requirements: OAuth 2.0 with JWT tokens for secure access",
                    "Data Format Specifications: JSON schema for request/response payloads"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'external',
                'name': config.get('name', f'External API: {api_endpoint}'),
                'endpoint': api_endpoint,
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"External source processed: {len(documents)} entries indexed",
                "insights": ["API documentation indexed", "Integration patterns captured", "Available for search"],
                "vector_embeddings": f"Added {len(doc_ids)} external embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error",
                "summary": f"Error processing external source: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    async def process_semantic_context(config):
        """Process semantic layer context (metadata, data models)"""
        try:
            documents = []
            
            # Process semantic layer information
            schema_content = config.get('schema', '')
            metadata_content = config.get('metadata', '')
            
            if schema_content or metadata_content:
                if schema_content:
                    documents.extend(parse_schema_content(schema_content))
                if metadata_content:
                    documents.extend(parse_metadata_content(metadata_content))
            else:
                # Demo semantic content
                documents = [
                    "Customer table: customer_id (PRIMARY KEY), first_name, last_name, email, created_date",
                    "Orders table: order_id (PRIMARY KEY), customer_id (FOREIGN KEY), order_date, total_amount",
                    "Products table: product_id (PRIMARY KEY), product_name, category, price, inventory_count",
                    "Data lineage: Raw transaction data → Cleaned transaction data → Aggregated daily sales",
                    "Business metrics: Customer Lifetime Value (CLV), Monthly Recurring Revenue (MRR), Churn Rate"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'semantic',
                'name': config.get('name', 'Semantic Layer'),
                'schema_type': config.get('schema_type', 'database'),
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"Semantic layer processed: {len(documents)} entities indexed",
                "insights": ["Data models mapped", "Relationships identified", "Metadata structured"],
                "vector_embeddings": f"Added {len(doc_ids)} semantic embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error", 
                "summary": f"Error processing semantic layer: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    async def process_application_context(config):
        """Process application flow and telemetry context"""
        try:
            documents = []
            app_name = config.get('name', 'Application')
            
            # Process application telemetry and flow data
            flow_data = config.get('flows', '')
            telemetry_data = config.get('telemetry', '')
            
            if flow_data or telemetry_data:
                if flow_data:
                    documents.extend(parse_application_flows(flow_data))
                if telemetry_data:
                    documents.extend(parse_telemetry_data(telemetry_data))
            else:
                # Demo application content
                documents = [
                    "User Journey: Login → Dashboard → Data Entry → Validation → Submission → Confirmation",
                    "Performance Metrics: Average page load time 2.3s, 99.5% uptime, 450ms API response time",
                    "Error Analysis: 404 errors account for 65% of issues, mostly from deprecated endpoints",
                    "Traffic Patterns: Peak usage between 9-11 AM and 2-4 PM, 40% mobile traffic",
                    "Security Events: 12 failed login attempts, 3 suspicious IP addresses blocked"
                ]
            
            # Add to vector database
            source_info = {
                'type': 'application',
                'name': config.get('name', 'Application Data'),
                'app_name': app_name,
                'config': config
            }
            
            doc_ids = vector_db.add_documents(documents, source_info)
            
            return {
                "status": "processed",
                "summary": f"Application data processed: {len(documents)} insights indexed",
                "insights": ["User flows mapped", "Performance metrics captured", "Error patterns analyzed"],
                "vector_embeddings": f"Added {len(doc_ids)} application embeddings to vector database",
                "doc_count": len(documents)
            }
        except Exception as e:
            return {
                "status": "error",
                "summary": f"Error processing application data: {str(e)}",
                "insights": [],
                "vector_embeddings": "failed"
            }

    # Utility functions for content processing
    def split_text_content(text, max_chunk_size=500):
        """Split text into manageable chunks"""
        words = text.split()
        chunks = []
        current_chunk = []
        current_size = 0
        
        for word in words:
            current_size += len(word) + 1
            if current_size > max_chunk_size and current_chunk:
                chunks.append(' '.join(current_chunk))
                current_chunk = [word]
                current_size = len(word)
            else:
                current_chunk.append(word)
        
        if current_chunk:
            chunks.append(' '.join(current_chunk))
        
        return chunks

    def split_code_content(code):
        """Split code into meaningful chunks"""
        lines = code.split('\n')
        chunks = []
        current_chunk = []
        
        for line in lines:
            stripped = line.strip()
            if stripped.startswith(('def ', 'class ', 'async def ')) and current_chunk:
                chunks.append('\n'.join(current_chunk))
                current_chunk = [line]
            else:
                current_chunk.append(line)
        
        if current_chunk:
            chunks.append('\n'.join(current_chunk))
        
        return [chunk for chunk in chunks if chunk.strip()]

    def simulate_pdf_content():
        """Simulate PDF content extraction"""
        return [
            "Executive Summary: This report outlines the strategic initiatives for digital transformation",
            "Market Analysis: Current trends show 40% growth in cloud adoption across enterprises",
            "Financial Projections: Expected ROI of 250% over the next 3 years",
            "Risk Assessment: Key risks include cybersecurity threats and regulatory changes",
            "Implementation Timeline: Phase 1 deployment scheduled for Q2 2024"
        ]

    def simulate_word_content():
        """Simulate Word document content extraction"""
        return [
            "Project Charter: Initiative to modernize legacy data processing systems",
            "Scope Definition: Migration of 15 core business applications to cloud infrastructure",
            "Stakeholder Analysis: Engagement required from IT, Finance, and Operations teams",
            "Success Criteria: 99.9% uptime, 50% reduction in processing time, zero data loss"
        ]

    def simulate_excel_content():
        """Simulate Excel content extraction"""
        return [
            "Sales Data Q1 2024: Total revenue $2.5M, 15% increase from previous quarter",
            "Customer Metrics: 1,250 active customers, 85% retention rate, 25 new acquisitions",
            "Product Performance: Product A leading with 40% market share",
            "Regional Analysis: North America 60%, Europe 30%, Asia-Pacific 10%"
        ]

    def parse_schema_content(schema):
        """Parse database schema or data model content"""
        # Simple parsing - in production, use proper schema parsers
        return [f"Schema definition: {schema}"]

    def parse_metadata_content(metadata):
        """Parse metadata content"""
        return [f"Metadata: {metadata}"]

    def get_file_type(filename):
        """Get file type from filename"""
        if '.' in filename:
            return filename.split('.')[-1].lower()
        return 'unknown'

    def simulate_github_api_content():
        """Simulate GitHub API content"""
        return [
            "Repository: user-management-service, 234 commits, 12 contributors",
            "Recent Issues: Authentication bug (#45), Performance optimization (#46)",
            "Pull Requests: Feature/oauth-integration (#12), Bugfix/login-error (#13)",
            "Code Structure: /src/auth/, /src/api/, /tests/, /docs/"
        ]

    def simulate_confluence_content():
        """Simulate Confluence content"""
        return [
            "Project Documentation: Architecture decisions and technical specifications",
            "Meeting Notes: Weekly standup outcomes and action items",
            "Process Guidelines: Code review checklist and deployment procedures",
            "Knowledge Base: Common troubleshooting steps and FAQ"
        ]

    def simulate_generic_api_content():
        """Simulate generic API content"""
        return [
            "API Response Format: JSON with status, data, and metadata fields",
            "Error Handling: Standard HTTP status codes with descriptive messages",
            "Pagination: Limit parameter with offset-based navigation",
            "Versioning: URL-based versioning scheme (/v1/, /v2/)"
        ]

    def parse_application_flows(flow_data):
        """Parse application flow data"""
        return [f"Application Flow: {flow_data}"]

    def parse_telemetry_data(telemetry_data):
        """Parse telemetry data"""
        return [f"Telemetry: {telemetry_data}"]

    @app.post("/api/vector/search")
    async def search_vector_database(request: Request):
        """Search the vector database for relevant context"""
        try:
            data = await request.json()
            query = data.get("query", "")
            top_k = data.get("top_k", 5)
            
            if not query:
                return JSONResponse({"success": False, "error": "Query is required"}, status_code=400)
            
            results = vector_db.search(query, top_k)
            
            return JSONResponse({
                "success": True,
                "query": query,
                "results": results,
                "total_documents": len(vector_db.documents),
                "message": f"Found {len(results)} relevant documents"
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/vector/get-context")
    async def get_context_for_query(request: Request):
        """Get formatted context for a specific query (for use in Agent Studio)"""
        try:
            data = await request.json()
            query = data.get("query", "")
            max_tokens = data.get("max_tokens", 1000)
            
            if not query:
                return JSONResponse({"success": False, "error": "Query is required"}, status_code=400)
            
            context = vector_db.get_context_summary(query, max_tokens)
            
            return JSONResponse({
                "success": True,
                "query": query,
                "context": context,
                "max_tokens": max_tokens,
                "message": "Context retrieved successfully"
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.get("/api/vector/stats")
    async def get_vector_database_stats():
        """Get vector database statistics"""
        try:
            stats = {
                "total_documents": len(vector_db.documents),
                "vector_dimension": vector_db.dimension,
                "index_size": vector_db.index.ntotal,
                "sources": {}
            }
            
            # Count documents by source type
            for doc in vector_db.documents:
                source_type = doc['source']
                if source_type not in stats['sources']:
                    stats['sources'][source_type] = 0
                stats['sources'][source_type] += 1
            
            return JSONResponse({
                "success": True,
                "stats": stats
            })
            
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # Return agent stores for use by other modules
    return {
        'langflow_agents': langflow_agents,
        'guided_agents': guided_agents,
        'studio_agents': studio_agents,
        'api_agents': api_agents,
        'json_agents': json_agents
    } 