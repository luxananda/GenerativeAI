from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from data_sources import DataSourceManager, AIDataSourceAssistant
import os
from pathlib import Path

app = FastAPI(title="Agentic Launchpad - Enhanced", version="2.0.0")

# Mount static files
try:
    app.mount("/static", StaticFiles(directory="static"), name="static")
except Exception:
    pass  # Directory might not exist

# Templates
templates = Jinja2Templates(directory="templates")

# Initialize AI assistant (no database connection needed for this)
print("Initializing AI Assistant with enhanced drivers...")
ai_assistant = AIDataSourceAssistant()

# Test the AI assistant immediately
test_result = ai_assistant.get_connection_guidance('postgresql')
print(f"✅ AI Assistant test - Drivers included: {'drivers' in test_result.get('guidance', {})}")

if 'drivers' in test_result.get('guidance', {}):
    drivers = test_result['guidance']['drivers']
    print(f"  📦 Python driver: {drivers['python']['name']}")
    print(f"  🖥️  Server: {drivers['server']['name']}")
    print(f"  🛠️  Client: {drivers['client']['name']}")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Main dashboard page"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/data-sources", response_class=HTMLResponse)
async def data_sources_page(request: Request):
    """Data sources configuration page"""
    return templates.TemplateResponse("data_sources.html", {"request": request})

@app.get("/api/connection-guidance/{source_type}")
async def get_connection_guidance(source_type: str):
    """Get AI-powered guidance for connecting to data source"""
    try:
        print(f"Getting guidance for: {source_type}")
        guidance = ai_assistant.get_connection_guidance(source_type)
        print(f"Guidance result: {guidance.get('success', False)}")
        if guidance.get('success'):
            print(f"Guidance has drivers: {'drivers' in guidance.get('guidance', {})}")
        return guidance
    except Exception as e:
        print(f"Error in guidance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/test-guidance")
async def test_guidance():
    """Test endpoint to verify guidance works"""
    try:
        result = ai_assistant.get_connection_guidance('postgresql')
        return {
            "test_success": result.get('success', False),
            "has_drivers": 'drivers' in result.get('guidance', {}),
            "guidance_keys": list(result.get('guidance', {}).keys()) if result.get('success') else [],
            "full_result": result
        }
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Enhanced Agentic Launchpad on port 9000...")
    uvicorn.run(app, host="0.0.0.0", port=9000) 