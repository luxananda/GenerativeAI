#!/usr/bin/env python3
"""
Agentic Launchpad - Modularized Version
A sophisticated, enterprise-grade low-code platform for AI agent management.
"""

import uvicorn
from core import create_app, setup_basic_routes, get_globals
from modules.data_sources_module import setup_data_source_routes
from modules.data_pipeline_module import setup_data_pipeline_routes
from modules.app_builder_module import setup_app_builder_routes
from modules.agent_dashboard_module import setup_agent_dashboard_routes
from modules.build_agents_module import setup_build_agents_routes
from modules.deploy_agents_module import setup_deploy_agents_routes
from modules.discovery_agents_module import setup_discovery_agents_routes
from modules.conversational_agents_module import setup_conversational_agents_routes

def create_application():
    """Create and configure the complete application"""
    # Create FastAPI app and templates
    app, templates = create_app()
    
    # Get global objects (database connections, managers, etc.)
    globals_dict = get_globals()
    
    # Setup basic routes (home, favicon, robots.txt, etc.)
    setup_basic_routes(app, templates)
    
    # Setup module routes
    setup_data_source_routes(app, globals_dict)
    setup_data_pipeline_routes(app, templates)
    setup_app_builder_routes(app, templates, globals_dict)
    setup_agent_dashboard_routes(app, templates)
    
    # Setup agent building routes and get agent stores
    agent_stores = setup_build_agents_routes(app, templates)
    
    # Setup discovery and conversational agent routes
    setup_discovery_agents_routes(app, templates)
    conversational_agents_dict = setup_conversational_agents_routes(app, templates)
    
    # Add conversational agents to agent stores
    agent_stores['conversational_agents'] = conversational_agents_dict
    
    # Setup agent deployment routes (needs complete agent stores)
    setup_deploy_agents_routes(app, templates, agent_stores)
    
    print("🚀 Agentic Launchpad modularized application initialized successfully!")
    print("📁 Modules loaded:")
    print("   ✅ Core (FastAPI setup, basic routes)")
    print("   ✅ Data Sources (SQL queries, data source management)")
    print("   ✅ Data Pipeline (AI data pipeline functionality)")
    print("   ✅ App Builder (app building and deployment)")
    print("   ✅ Agent Dashboard (basic agent management)")
    print("   ✅ Build Agents (agent creation functionality)")
    print("   ✅ Deploy Agents (agent deployment and execution)")
    print("   ✅ Discovery Agents (discovery and analysis)")
    print("   ✅ Conversational Agents (conversational functionality)")
    print("🎯 Application ready!")
    
    return app

# Create the application instance
app = create_application()

if __name__ == "__main__":
    print("🚀 Starting Agentic Launchpad on port 9000...")
    uvicorn.run(app, host="0.0.0.0", port=9000) 