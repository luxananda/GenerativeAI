import duckdb
import pandas as pd
import sqlalchemy
from sqlalchemy import create_engine, text
import os
import json
from typing import Dict, List, Optional, Any
import boto3
from azure.storage.blob import BlobServiceClient
from google.cloud import storage as gcs
import requests
import yaml

class DataSourceManager:
    """Manages connections to multiple data sources"""
    
    def __init__(self):
        self.connections = {}
        self.data_sources = {}
        self.load_configurations()
    
    def load_configurations(self):
        """Load saved data source configurations"""
        try:
            if os.path.exists('data_sources.json'):
                with open('data_sources.json', 'r') as f:
                    self.data_sources = json.load(f)
        except Exception as e:
            print(f"Error loading configurations: {e}")
            self.data_sources = {}
    
    def save_configurations(self):
        """Save data source configurations"""
        try:
            with open('data_sources.json', 'w') as f:
                json.dump(self.data_sources, f, indent=2)
        except Exception as e:
            print(f"Error saving configurations: {e}")
    
    def add_data_source(self, name: str, source_type: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Add a new data source configuration"""
        try:
            # Validate and test connection
            connection_result = self.test_connection(source_type, config)
            if connection_result['success']:
                self.data_sources[name] = {
                    'type': source_type,
                    'config': config,
                    'status': 'active',
                    'tables': connection_result.get('tables', [])
                }
                self.save_configurations()
                return {'success': True, 'message': f'Data source "{name}" added successfully'}
            else:
                return {'success': False, 'message': connection_result['error']}
        except Exception as e:
            return {'success': False, 'message': f'Error adding data source: {str(e)}'}
    
    def test_connection(self, source_type: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test connection to a data source"""
        try:
            if source_type == 'postgresql':
                return self._test_postgresql(config)
            elif source_type == 'mysql':
                return self._test_mysql(config)
            elif source_type == 'mssql':
                return self._test_mssql(config)
            elif source_type == 'sqlite':
                return self._test_sqlite(config)
            elif source_type == 'snowflake':
                return self._test_snowflake(config)
            elif source_type == 'bigquery':
                return self._test_bigquery(config)
            elif source_type == 's3':
                return self._test_s3(config)
            elif source_type == 'azure_blob':
                return self._test_azure_blob(config)
            elif source_type == 'api':
                return self._test_api(config)
            else:
                return {'success': False, 'error': f'Unsupported source type: {source_type}'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_postgresql(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test PostgreSQL connection"""
        try:
            conn_string = f"postgresql://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 5432)}/{config['database']}"
            engine = create_engine(conn_string)
            with engine.connect() as conn:
                result = conn.execute(text("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"))
                tables = [row[0] for row in result]
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_mysql(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test MySQL connection"""
        try:
            conn_string = f"mysql+pymysql://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 3306)}/{config['database']}"
            engine = create_engine(conn_string)
            with engine.connect() as conn:
                result = conn.execute(text("SHOW TABLES"))
                tables = [row[0] for row in result]
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_mssql(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test SQL Server connection"""
        try:
            conn_string = f"mssql+pyodbc://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 1433)}/{config['database']}?driver=ODBC+Driver+17+for+SQL+Server"
            engine = create_engine(conn_string)
            with engine.connect() as conn:
                result = conn.execute(text("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE'"))
                tables = [row[0] for row in result]
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_sqlite(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test SQLite connection"""
        try:
            conn_string = f"sqlite:///{config['file_path']}"
            engine = create_engine(conn_string)
            with engine.connect() as conn:
                result = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))
                tables = [row[0] for row in result]
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_snowflake(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test Snowflake connection"""
        try:
            conn_string = f"snowflake://{config['username']}:{config['password']}@{config['account']}/{config['database']}/{config['schema']}?warehouse={config['warehouse']}"
            engine = create_engine(conn_string)
            with engine.connect() as conn:
                result = conn.execute(text("SHOW TABLES"))
                tables = [row[1] for row in result]  # Snowflake returns table name in second column
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_bigquery(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test BigQuery connection"""
        try:
            conn_string = f"bigquery://{config['project_id']}/{config['dataset_id']}"
            engine = create_engine(conn_string, credentials_path=config.get('credentials_path'))
            with engine.connect() as conn:
                result = conn.execute(text(f"SELECT table_name FROM `{config['project_id']}.{config['dataset_id']}.INFORMATION_SCHEMA.TABLES`"))
                tables = [row[0] for row in result]
            return {'success': True, 'tables': tables}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_s3(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test S3 connection"""
        try:
            s3_client = boto3.client(
                's3',
                aws_access_key_id=config['access_key'],
                aws_secret_access_key=config['secret_key'],
                region_name=config.get('region', 'us-east-1')
            )
            response = s3_client.list_objects_v2(Bucket=config['bucket'], MaxKeys=1)
            return {'success': True, 'tables': ['s3_files']}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_azure_blob(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test Azure Blob Storage connection"""
        try:
            blob_service_client = BlobServiceClient(
                account_url=f"https://{config['account_name']}.blob.core.windows.net",
                credential=config['account_key']
            )
            container_client = blob_service_client.get_container_client(config['container_name'])
            blob_list = container_client.list_blobs(max_results=1)
            return {'success': True, 'tables': ['azure_blobs']}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _test_api(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Test API connection"""
        try:
            headers = config.get('headers', {})
            response = requests.get(config['url'], headers=headers, timeout=10)
            response.raise_for_status()
            return {'success': True, 'tables': ['api_data']}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_connection(self, source_name: str):
        """Get or create connection for a data source"""
        if source_name not in self.data_sources:
            raise ValueError(f"Data source '{source_name}' not found")
        
        if source_name not in self.connections:
            source_config = self.data_sources[source_name]
            self.connections[source_name] = self._create_connection(source_config)
        
        return self.connections[source_name]
    
    def _create_connection(self, source_config: Dict[str, Any]):
        """Create connection based on source configuration"""
        source_type = source_config['type']
        config = source_config['config']
        
        if source_type in ['postgresql', 'mysql', 'mssql', 'sqlite', 'snowflake', 'bigquery']:
            return self._create_sql_connection(source_type, config)
        elif source_type == 's3':
            return boto3.client('s3', **config)
        elif source_type == 'azure_blob':
            return BlobServiceClient(
                account_url=f"https://{config['account_name']}.blob.core.windows.net",
                credential=config['account_key']
            )
        else:
            raise ValueError(f"Unsupported source type: {source_type}")
    
    def _create_sql_connection(self, source_type: str, config: Dict[str, Any]):
        """Create SQL connection"""
        if source_type == 'postgresql':
            conn_string = f"postgresql://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 5432)}/{config['database']}"
        elif source_type == 'mysql':
            conn_string = f"mysql+pymysql://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 3306)}/{config['database']}"
        elif source_type == 'mssql':
            conn_string = f"mssql+pyodbc://{config['username']}:{config['password']}@{config['host']}:{config.get('port', 1433)}/{config['database']}?driver=ODBC+Driver+17+for+SQL+Server"
        elif source_type == 'sqlite':
            conn_string = f"sqlite:///{config['file_path']}"
        elif source_type == 'snowflake':
            conn_string = f"snowflake://{config['username']}:{config['password']}@{config['account']}/{config['database']}/{config['schema']}?warehouse={config['warehouse']}"
        elif source_type == 'bigquery':
            conn_string = f"bigquery://{config['project_id']}/{config['dataset_id']}"
        
        return create_engine(conn_string)
    
    def execute_query(self, source_name: str, query: str) -> pd.DataFrame:
        """Execute query on specified data source"""
        if source_name == 'duckdb':
            # Default DuckDB connection
            conn = duckdb.connect('app_data.db')
            return conn.execute(query).df()
        
        source_config = self.data_sources[source_name]
        source_type = source_config['type']
        
        if source_type in ['postgresql', 'mysql', 'mssql', 'sqlite', 'snowflake', 'bigquery']:
            engine = self.get_connection(source_name)
            return pd.read_sql(query, engine)
        else:
            raise ValueError(f"Query execution not supported for source type: {source_type}")
    
    def get_table_info(self, source_name: str, table_name: str) -> Dict[str, Any]:
        """Get table information from specified data source"""
        if source_name == 'duckdb':
            conn = duckdb.connect('app_data.db')
            result = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
            columns = []
            for row in result:
                columns.append({
                    "name": row[1],
                    "type": row[2],
                    "nullable": not row[3],
                    "primary_key": bool(row[5])
                })
            return {"table_name": table_name, "columns": columns}
        
        source_config = self.data_sources[source_name]
        source_type = source_config['type']
        
        if source_type == 'postgresql':
            engine = self.get_connection(source_name)
            query = f"""
                SELECT column_name, data_type, is_nullable, 
                       CASE WHEN column_name IN (
                           SELECT column_name FROM information_schema.key_column_usage 
                           WHERE table_name = '{table_name}'
                       ) THEN true ELSE false END as is_primary_key
                FROM information_schema.columns 
                WHERE table_name = '{table_name}'
            """
            df = pd.read_sql(query, engine)
            columns = df.to_dict('records')
            return {"table_name": table_name, "columns": columns}
        
        # Add more database-specific implementations as needed
        return {"table_name": table_name, "columns": []}
    
    def list_data_sources(self) -> List[Dict[str, Any]]:
        """List all configured data sources"""
        sources = []
        for name, config in self.data_sources.items():
            sources.append({
                'name': name,
                'type': config['type'],
                'status': config.get('status', 'unknown'),
                'tables': config.get('tables', [])
            })
        return sources
    
    def upload_file(self, file_path: str, file_name: str) -> Dict[str, Any]:
        """Process uploaded file and create temporary data source"""
        try:
            file_ext = os.path.splitext(file_name)[1].lower()
            
            if file_ext in ['.csv']:
                df = pd.read_csv(file_path)
            elif file_ext in ['.xlsx', '.xls']:
                df = pd.read_excel(file_path)
            elif file_ext in ['.parquet']:
                df = pd.read_parquet(file_path)
            elif file_ext in ['.json']:
                df = pd.read_json(file_path)
            else:
                return {'success': False, 'error': f'Unsupported file type: {file_ext}'}
            
            # Store in DuckDB
            conn = duckdb.connect('app_data.db')
            table_name = f"uploaded_{os.path.splitext(file_name)[0].replace(' ', '_').replace('-', '_')}"
            conn.execute(f"DROP TABLE IF EXISTS {table_name}")
            conn.execute(f"CREATE TABLE {table_name} AS SELECT * FROM df")
            
            # Get column info
            columns_info = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
            columns = [{'name': col[1], 'type': col[2]} for col in columns_info]
            
            return {
                'success': True,
                'table_name': table_name,
                'rows': len(df),
                'columns': columns,
                'message': f'File uploaded successfully as table: {table_name}'
            }
            
        except Exception as e:
            return {'success': False, 'error': f'Error processing file: {str(e)}'}

class AIDataSourceAssistant:
    """AI assistant for data source configuration and guidance"""
    
    def __init__(self):
        self.connection_templates = {
            'postgresql': {
                'required_fields': ['host', 'port', 'database', 'username', 'password'],
                'optional_fields': ['schema'],
                'example': {
                    'host': 'localhost',
                    'port': 5432,
                    'database': 'mydatabase',
                    'username': 'user',
                    'password': 'password'
                },
                'instructions': "PostgreSQL is a powerful open-source database. Ensure your server is accessible and credentials are correct.",
                'drivers': {
                    'python': {
                        'name': 'psycopg2-binary',
                        'install': 'pip install psycopg2-binary',
                        'docs': 'https://www.psycopg.org/docs/'
                    },
                    'server': {
                        'name': 'PostgreSQL Server',
                        'download': 'https://www.postgresql.org/download/',
                        'docs': 'https://www.postgresql.org/docs/'
                    },
                    'client': {
                        'name': 'pgAdmin (GUI Client)',
                        'download': 'https://www.pgadmin.org/download/',
                        'alternative': 'DBeaver: https://dbeaver.io/download/'
                    }
                }
            },
            'mysql': {
                'required_fields': ['host', 'port', 'database', 'username', 'password'],
                'optional_fields': [],
                'example': {
                    'host': 'localhost',
                    'port': 3306,
                    'database': 'mydatabase',
                    'username': 'user',
                    'password': 'password'
                },
                'instructions': "MySQL is widely used for web applications. Check that the MySQL service is running.",
                'drivers': {
                    'python': {
                        'name': 'PyMySQL',
                        'install': 'pip install PyMySQL',
                        'docs': 'https://pymysql.readthedocs.io/'
                    },
                    'server': {
                        'name': 'MySQL Server',
                        'download': 'https://dev.mysql.com/downloads/mysql/',
                        'docs': 'https://dev.mysql.com/doc/'
                    },
                    'client': {
                        'name': 'MySQL Workbench',
                        'download': 'https://dev.mysql.com/downloads/workbench/',
                        'alternative': 'phpMyAdmin: https://www.phpmyadmin.net/'
                    }
                }
            },
            'mssql': {
                'required_fields': ['host', 'port', 'database', 'username', 'password'],
                'optional_fields': ['driver'],
                'example': {
                    'host': 'localhost',
                    'port': 1433,
                    'database': 'mydatabase',
                    'username': 'user',
                    'password': 'password'
                },
                'instructions': "SQL Server is Microsoft's enterprise database. Ensure SQL Server service is running and firewall allows connections.",
                'drivers': {
                    'python': {
                        'name': 'pyodbc',
                        'install': 'pip install pyodbc',
                        'docs': 'https://github.com/mkleehammer/pyodbc'
                    },
                    'odbc_driver': {
                        'name': 'Microsoft ODBC Driver for SQL Server',
                        'windows': 'https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server',
                        'linux': 'https://docs.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server',
                        'mac': 'https://docs.microsoft.com/en-us/sql/connect/odbc/linux-mac/install-microsoft-odbc-driver-sql-server-macos'
                    },
                    'server': {
                        'name': 'SQL Server Express (Free)',
                        'download': 'https://www.microsoft.com/en-us/sql-server/sql-server-downloads',
                        'docs': 'https://docs.microsoft.com/en-us/sql/'
                    },
                    'client': {
                        'name': 'SQL Server Management Studio (SSMS)',
                        'download': 'https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms',
                        'alternative': 'Azure Data Studio: https://docs.microsoft.com/en-us/sql/azure-data-studio/'
                    }
                }
            },
            'snowflake': {
                'required_fields': ['account', 'username', 'password', 'database', 'schema', 'warehouse'],
                'optional_fields': ['role'],
                'example': {
                    'account': 'your-account.snowflakecomputing.com',
                    'username': 'user',
                    'password': 'password',
                    'database': 'DATABASE',
                    'schema': 'SCHEMA',
                    'warehouse': 'WAREHOUSE'
                },
                'instructions': "Snowflake is a cloud data platform. Account identifier format varies by region.",
                'drivers': {
                    'python': {
                        'name': 'snowflake-connector-python',
                        'install': 'pip install snowflake-connector-python',
                        'docs': 'https://docs.snowflake.com/en/user-guide/python-connector.html'
                    },
                    'account_setup': {
                        'name': 'Snowflake Account',
                        'signup': 'https://signup.snowflake.com/',
                        'docs': 'https://docs.snowflake.com/en/user-guide-getting-started.html'
                    },
                    'client': {
                        'name': 'SnowSQL CLI',
                        'download': 'https://docs.snowflake.com/en/user-guide/snowsql-install-config.html',
                        'web_ui': 'Access via web UI: https://app.snowflake.com/'
                    }
                }
            },
            'bigquery': {
                'required_fields': ['project_id', 'dataset_id', 'credentials_path'],
                'optional_fields': ['location'],
                'example': {
                    'project_id': 'my-gcp-project',
                    'dataset_id': 'my_dataset',
                    'credentials_path': '/path/to/service-account.json'
                },
                'instructions': "BigQuery is Google's serverless data warehouse. Requires service account credentials.",
                'drivers': {
                    'python': {
                        'name': 'google-cloud-bigquery',
                        'install': 'pip install google-cloud-bigquery',
                        'docs': 'https://cloud.google.com/bigquery/docs/quickstarts/quickstart-client-libraries'
                    },
                    'credentials': {
                        'name': 'Service Account Key',
                        'setup': 'https://cloud.google.com/bigquery/docs/authentication/service-account-file',
                        'console': 'https://console.cloud.google.com/iam-admin/serviceaccounts'
                    },
                    'account_setup': {
                        'name': 'Google Cloud Account',
                        'signup': 'https://cloud.google.com/gcp/',
                        'free_tier': 'https://cloud.google.com/free'
                    },
                    'client': {
                        'name': 'BigQuery Web UI',
                        'access': 'https://console.cloud.google.com/bigquery',
                        'cli': 'gcloud CLI: https://cloud.google.com/sdk/docs/install'
                    }
                }
            },
            'sqlite': {
                'required_fields': ['file_path'],
                'optional_fields': [],
                'example': {
                    'file_path': '/path/to/database.db'
                },
                'instructions': "SQLite is a file-based database. No server required, just specify the database file path.",
                'drivers': {
                    'python': {
                        'name': 'sqlite3 (built-in)',
                        'install': 'Included with Python - no installation needed',
                        'docs': 'https://docs.python.org/3/library/sqlite3.html'
                    },
                    'client': {
                        'name': 'DB Browser for SQLite',
                        'download': 'https://sqlitebrowser.org/dl/',
                        'alternative': 'SQLiteStudio: https://sqlitestudio.pl/'
                    },
                    'command_line': {
                        'name': 'SQLite CLI',
                        'download': 'https://sqlite.org/download.html',
                        'docs': 'https://sqlite.org/cli.html'
                    }
                }
            },
            's3': {
                'required_fields': ['bucket', 'access_key', 'secret_key', 'region'],
                'optional_fields': ['prefix'],
                'example': {
                    'bucket': 'my-data-bucket',
                    'access_key': 'AKIAIOSFODNN7EXAMPLE',
                    'secret_key': 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
                    'region': 'us-east-1'
                },
                'instructions': "AWS S3 for file storage and data lakes. Requires AWS credentials with S3 access permissions.",
                'drivers': {
                    'python': {
                        'name': 'boto3',
                        'install': 'pip install boto3',
                        'docs': 'https://boto3.amazonaws.com/v1/documentation/api/latest/index.html'
                    },
                    'aws_account': {
                        'name': 'AWS Account',
                        'signup': 'https://aws.amazon.com/free/',
                        'console': 'https://console.aws.amazon.com/'
                    },
                    'credentials': {
                        'name': 'AWS Access Keys',
                        'setup': 'https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html',
                        'iam_console': 'https://console.aws.amazon.com/iam/'
                    },
                    'client': {
                        'name': 'AWS CLI',
                        'download': 'https://aws.amazon.com/cli/',
                        'web_console': 'S3 Console: https://s3.console.aws.amazon.com/'
                    }
                }
            },
            'azure_blob': {
                'required_fields': ['account_name', 'account_key', 'container_name'],
                'optional_fields': ['connection_string'],
                'example': {
                    'account_name': 'mystorageaccount',
                    'account_key': 'your-account-key-here',
                    'container_name': 'data-container'
                },
                'instructions': "Azure Blob Storage for cloud file storage. Requires Azure Storage Account credentials.",
                'drivers': {
                    'python': {
                        'name': 'azure-storage-blob',
                        'install': 'pip install azure-storage-blob',
                        'docs': 'https://docs.microsoft.com/en-us/azure/storage/blobs/storage-quickstart-blobs-python'
                    },
                    'azure_account': {
                        'name': 'Azure Account',
                        'signup': 'https://azure.microsoft.com/en-us/free/',
                        'portal': 'https://portal.azure.com/'
                    },
                    'storage_account': {
                        'name': 'Azure Storage Account',
                        'setup': 'https://docs.microsoft.com/en-us/azure/storage/common/storage-account-create',
                        'portal': 'https://portal.azure.com/#create/Microsoft.StorageAccount'
                    },
                    'client': {
                        'name': 'Azure Storage Explorer',
                        'download': 'https://azure.microsoft.com/en-us/features/storage-explorer/',
                        'cli': 'Azure CLI: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli'
                    }
                }
            }
        }
    
    def get_connection_guidance(self, source_type: str) -> Dict[str, Any]:
        """Get AI guidance for connecting to a specific data source type"""
        if source_type not in self.connection_templates:
            return {
                'success': False,
                'message': f'No guidance available for source type: {source_type}'
            }
        
        template = self.connection_templates[source_type]
        
        guidance = {
            'source_type': source_type,
            'required_fields': template['required_fields'],
            'optional_fields': template['optional_fields'],
            'example_config': template['example'],
            'instructions': template['instructions'],
            'drivers': template.get('drivers', {}),
            'ai_tips': self._generate_ai_tips(source_type)
        }
        
        return {'success': True, 'guidance': guidance}
    
    def _generate_ai_tips(self, source_type: str) -> List[str]:
        """Generate AI-powered tips for data source connection"""
        tips = {
            'postgresql': [
                "Check if PostgreSQL service is running: sudo systemctl status postgresql",
                "Default port is 5432, but verify with your DBA",
                "Ensure user has necessary permissions: GRANT SELECT ON ALL TABLES IN SCHEMA public TO username;",
                "Test connection: psql -h host -p port -U username -d database"
            ],
            'mysql': [
                "Default port is 3306, verify it's not blocked by firewall",
                "Check MySQL service: sudo systemctl status mysql",
                "Grant permissions: GRANT SELECT ON database.* TO 'username'@'%';",
                "Test with: mysql -h host -P port -u username -p database"
            ],
            'snowflake': [
                "Account identifier includes region: account.region.snowflakecomputing.com",
                "Warehouse must be running for queries to execute",
                "Use uppercase for database, schema, and warehouse names",
                "Check network policies if connection fails"
            ]
        }
        
        return tips.get(source_type, ["Ensure network connectivity and proper credentials"])
    
    def suggest_optimal_configuration(self, source_type: str, use_case: str) -> Dict[str, Any]:
        """AI-powered suggestions for optimal configuration"""
        suggestions = {
            'postgresql': {
                'analytics': {
                    'connection_pool_size': 20,
                    'query_timeout': 300,
                    'read_only': True
                },
                'operational': {
                    'connection_pool_size': 5,
                    'query_timeout': 30,
                    'read_only': False
                }
            }
        }
        
        return suggestions.get(source_type, {}).get(use_case, {}) 