# Agentic Launchpad

A sophisticated, enterprise-grade low-code platform inspired by Oracle APEX and designed with the professional aesthetics of [GIC (Government of Singapore Investment Corporation)](https://www.gic.com.sg). Combines the power of AI with SQL-driven application development in a beautiful, financial-institution quality interface. Build data-driven applications and dashboards using natural language queries that are automatically converted to SQL.

## 🌟 Features

### Current Features (v1.0)
- **Natural Language to SQL**: Write queries in plain English and let AI convert them to SQL
- **Interactive Dashboard**: Beautiful, responsive web interface built with Tailwind CSS
- **Real-time Charts**: Automatic chart generation using Plotly.js based on your data
- **Table Explorer**: Browse table structures and sample data
- **Instant Execution**: Run queries and see results immediately
- **Sample Data**: Pre-loaded with employee and sales data for testing

### Planned Features
- **Visual App Builder**: Drag-and-drop interface for building applications
- **AI-Assisted Development**: Describe your app and let AI build it
- **Component Library**: Pre-built UI components (forms, charts, tables)
- **One-Click Deployment**: Deploy applications instantly
- **File Upload**: Support for CSV, Excel, and PDF processing

## 🏗️ Architecture

```
Frontend (HTML/JS/Tailwind) ←→ FastAPI Backend ←→ DuckDB Database
                            ↕
                        AI Agent (SQL Generation)
```

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip

### Installation

1. **Clone and setup**:
```bash
git clone <your-repo>
cd APEX_AGENT
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Run the application**:
```bash
python main.py
```

4. **Open your browser**:
Navigate to `http://localhost:9000`

## 🎯 How to Use

### 1. Natural Language Queries
Toggle "Use AI Natural Language" and try these examples:
- "Show all employees"
- "Count records in employees"
- "Show sales by region"

### 2. Direct SQL Queries
Turn off AI mode and run direct SQL:
```sql
SELECT department, AVG(salary) as avg_salary 
FROM employees 
GROUP BY department
```

### 3. Generate Charts
After running a query:
1. Click "Generate Chart" button
2. AI automatically suggests the best chart type
3. Interactive charts are rendered using Plotly

### 4. Explore Tables
- Select tables from the dropdown
- View column information and data types
- See primary keys and constraints

## 🗃️ Sample Data

The platform comes with pre-loaded sample data:

### Employees Table
- Employee information with departments, salaries, and hire dates
- Perfect for HR analytics and reporting

### Sales Table
- Sales data with products, amounts, dates, and regions
- Great for revenue analysis and business intelligence

## 🤖 AI Agent Capabilities

The built-in AI agent can:
- Convert natural language to SQL queries
- Suggest appropriate visualizations based on data types
- Recognize common query patterns
- Handle table relationships

### Supported Natural Language Patterns:
- "Show/List/Display all [table]"
- "Count records/rows in [table]"
- "Describe [table]" or "Show columns in [table]"
- "Show [column] by [column]"

## 🛠️ Technical Details

### Backend
- **FastAPI**: Modern, fast web framework
- **DuckDB**: Embedded analytical database
- **Pandas**: Data manipulation and analysis
- **Plotly**: Interactive chart generation

### Frontend
- **HTML5**: Semantic markup
- **Tailwind CSS**: Utility-first CSS framework
- **Vanilla JavaScript**: No framework dependencies
- **Font Awesome**: Icon library

### Database
- **DuckDB**: In-process SQL OLAP database
- **File-based**: No external database server needed
- **SQL Compatible**: Standard SQL queries
- **High Performance**: Optimized for analytics

## 📁 Project Structure

```
APEX_AGENT/
├── main.py              # FastAPI application
├── requirements.txt     # Python dependencies
├── app_data.db         # DuckDB database file (created on first run)
├── templates/          # HTML templates
│   ├── index.html      # Main dashboard
│   └── app_builder.html # App builder (coming soon)
└── static/            # Static assets
    ├── css/           # Custom CSS files
    └── js/            # Custom JavaScript files
```

## 🔮 Roadmap

### Phase 1: Core Platform ✅
- [x] Basic query interface
- [x] Natural language to SQL
- [x] Chart generation
- [x] Table exploration

### Phase 2: App Builder 🚧
- [ ] Drag-and-drop interface
- [ ] Component library
- [ ] Visual query builder
- [ ] Form builder

### Phase 3: Advanced AI 📋
- [ ] Advanced SQL generation
- [ ] Query optimization suggestions
- [ ] Data insights generation
- [ ] Natural language reporting

### Phase 4: Enterprise Features 📋
- [ ] User authentication
- [ ] Multi-tenant support
- [ ] API endpoints
- [ ] Export capabilities

## 🤝 Contributing

This project is designed to be simple and extensible. Key areas for contribution:

1. **AI Agent Enhancement**: Improve natural language processing
2. **Visualization**: Add more chart types and customization
3. **Components**: Build reusable UI components
4. **Performance**: Optimize query execution and rendering

## 📋 API Reference

### GET `/api/tables`
Returns list of available tables

### POST `/api/query`
Execute SQL query or natural language query
```json
{
  "query": "show all employees",
  "table_name": "employees",
  "use_ai": true
}
```

### GET `/api/table-info/{table_name}`
Get table structure and column information

### POST `/api/generate-chart`
Generate chart from data
```json
{
  "data": [...],
  "type": "bar",
  "x": "department",
  "y": "salary",
  "title": "Salary by Department"
}
```

## 🎨 Design Philosophy

This platform follows the **APEX philosophy**:
- **Simple**: Minimal learning curve
- **Declarative**: Describe what you want, not how to build it
- **Data-Driven**: SQL queries power everything
- **Rapid**: From idea to working app in minutes
- **Visual**: Rich, interactive user interfaces

## 📄 License

This project is designed for educational and internal use within financial organizations. Please ensure compliance with your organization's policies before deployment.

---

**Built with ❤️ using FastAPI, DuckDB, and AI** 