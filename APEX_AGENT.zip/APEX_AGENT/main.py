from fastapi import FastAPI, Request, Form, HTTPException, UploadFile, File, Response
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import duckdb
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import os
from datetime import datetime
from typing import Optional
import re
from data_sources import DataSourceManager, AIDataSourceAssistant
import os
from pathlib import Path
import asyncio
import openai
import anthropic

app = FastAPI(title="Agentic Launchpad", version="1.0.0")

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Templates
templates = Jinja2Templates(directory="templates")

# Initialize DuckDB connection
conn = duckdb.connect('app_data.db')

class SimpleAIAgent:
    """Simple AI agent for SQL generation and data interpretation"""
    
    def __init__(self):
        self.sql_patterns = {
            'show tables': 'SHOW TABLES',
            'list tables': 'SHOW TABLES',
            'describe table': 'DESCRIBE {}',
            'select all from': 'SELECT * FROM {} LIMIT 100',
            'count records': 'SELECT COUNT(*) as total_records FROM {}',
            'show columns': 'PRAGMA table_info({})',
        }
    
    def natural_language_to_sql(self, query: str, table_name: str = None) -> str:
        """Convert natural language to SQL query"""
        query_lower = query.lower().strip()
        
        # Basic pattern matching for simple queries
        if 'show tables' in query_lower or 'list tables' in query_lower:
            return 'SHOW TABLES'
        
        if table_name:
            if 'count' in query_lower and 'record' in query_lower:
                return f'SELECT COUNT(*) as total_records FROM {table_name}'
            
            if 'show all' in query_lower or 'select all' in query_lower:
                return f'SELECT * FROM {table_name} LIMIT 100'
            
            if 'describe' in query_lower or 'column' in query_lower:
                return f'PRAGMA table_info({table_name})'
        
        # If no pattern matches, return the query as-is (assuming it's already SQL)
        return query
    
    def generate_chart_suggestion(self, df: pd.DataFrame, query: str) -> dict:
        """Suggest appropriate chart type based on data"""
        if df.empty:
            return {"type": "no_data", "message": "No data to visualize"}
        
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        if len(numeric_cols) >= 2:
            return {
                "type": "scatter",
                "x": numeric_cols[0],
                "y": numeric_cols[1],
                "title": f"{numeric_cols[1]} vs {numeric_cols[0]}"
            }
        elif len(numeric_cols) == 1 and len(categorical_cols) >= 1:
            return {
                "type": "bar",
                "x": categorical_cols[0],
                "y": numeric_cols[0],
                "title": f"{numeric_cols[0]} by {categorical_cols[0]}"
            }
        elif len(categorical_cols) >= 1:
            return {
                "type": "pie",
                "values": categorical_cols[0],
                "title": f"Distribution of {categorical_cols[0]}"
            }
        else:
            return {
                "type": "table",
                "title": "Data Table"
            }

# Initialize AI agent
ai_agent = SimpleAIAgent()

# Initialize managers
data_source_manager = DataSourceManager()
ai_assistant = AIDataSourceAssistant()

# Store for deployed applications
deployed_apps = {}
app_counter = 1

# Test that ai_assistant is working correctly
print("AI Assistant initialized - testing guidance...")
test_result = ai_assistant.get_connection_guidance('postgresql')
print(f"Test result has drivers: {'drivers' in test_result.get('guidance', {})}")

# Initialize sample data
def init_sample_data():
    """Create sample tables like APEX demo data"""
    try:
        # Create employees table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY,
                first_name VARCHAR(50),
                last_name VARCHAR(50),
                email VARCHAR(100),
                department VARCHAR(50),
                salary DECIMAL(10,2),
                hire_date DATE
            )
        """)
        
        # Insert sample data
        sample_employees = [
            (1, 'John', 'Doe', 'john.doe@company.com', 'Engineering', 75000, '2023-01-15'),
            (2, 'Jane', 'Smith', 'jane.smith@company.com', 'Marketing', 65000, '2023-02-20'),
            (3, 'Bob', 'Johnson', 'bob.johnson@company.com', 'Engineering', 80000, '2022-11-10'),
            (4, 'Alice', 'Brown', 'alice.brown@company.com', 'Sales', 70000, '2023-03-05'),
            (5, 'Charlie', 'Wilson', 'charlie.wilson@company.com', 'HR', 60000, '2023-01-30'),
        ]
        
        conn.execute("DELETE FROM employees")  # Clear existing data
        conn.executemany(
            "INSERT INTO employees VALUES (?, ?, ?, ?, ?, ?, ?)",
            sample_employees
        )
        
        # Create sales table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY,
                product_name VARCHAR(100),
                sales_amount DECIMAL(10,2),
                sale_date DATE,
                region VARCHAR(50)
            )
        """)
        
        sample_sales = [
            (1, 'Product A', 15000, '2023-11-01', 'North'),
            (2, 'Product B', 25000, '2023-11-02', 'South'),
            (3, 'Product A', 18000, '2023-11-03', 'East'),
            (4, 'Product C', 30000, '2023-11-04', 'West'),
            (5, 'Product B', 22000, '2023-11-05', 'North'),
        ]
        
        conn.execute("DELETE FROM sales")
        conn.executemany(
            "INSERT INTO sales VALUES (?, ?, ?, ?, ?)",
            sample_sales
        )
        
    except Exception as e:
        print(f"Error initializing sample data: {e}")

# Initialize sample data on startup
init_sample_data()

@app.get("/")
async def home(request: Request):
    """Redirect to Agent Dashboard (main page is now agent-focused)"""
    return RedirectResponse(url="/agents", status_code=302)

@app.get("/.devtools.json")
async def devtools_config():
    """Handle devtools.json requests to prevent 404 errors"""
    return JSONResponse({
        "name": "Agentic Launchpad",
        "version": "1.0.0",
        "devtools": {
            "enabled": True
        }
    })

@app.get("/favicon.ico")
async def favicon():
    """Handle favicon requests to prevent 404 errors"""
    return Response(status_code=204)  # No Content

@app.get("/robots.txt")
async def robots():
    """Handle robots.txt requests"""
    return Response(content="User-agent: *\nDisallow:", media_type="text/plain")

# Keep old dashboard route hidden but functional for later use
@app.get("/old-dashboard", response_class=HTMLResponse)
async def old_dashboard(request: Request):
    """Old data dashboard page (hidden but preserved)"""
    return templates.TemplateResponse("index.html", {"request": request})

# Keep old app builder route hidden but functional for later use
@app.get("/old-app-builder", response_class=HTMLResponse)
async def old_app_builder(request: Request):
    """Old app builder interface (hidden but preserved)"""
    return templates.TemplateResponse("app_builder.html", {"request": request})

# Keep old data sources route hidden but functional for later use
@app.get("/old-data-sources", response_class=HTMLResponse)
async def old_data_sources_page(request: Request):
    """Old data sources configuration page (hidden but preserved)"""
    return templates.TemplateResponse("data_sources.html", {"request": request})

@app.get("/data-pipeline-chat")
async def data_pipeline_chat(request: Request):
    """Serve the AI data pipeline chat interface"""
    return templates.TemplateResponse("data_pipeline_chat.html", {"request": request})

@app.post("/api/ai-pipeline-request")
async def process_pipeline_request(request: Request):
    """Process natural language pipeline requests"""
    try:
        data = await request.json()
        message = data.get("message", "")
        
        # Here you would integrate with a proper NLP model
        # For now, using simple keyword matching as demonstration
        
        response = {
            "message": "I understand your request! This would be processed by a proper NLP model in production.",
            "sql": "SELECT * FROM your_table WHERE condition = 'value'",
            "pipeline_step": {
                "type": "transform",
                "description": "Data transformation step",
                "status": "ready"
            }
        }
        
        return JSONResponse(response)
        
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/tables")
async def get_tables():
    """Get list of available tables"""
    try:
        result = conn.execute("SHOW TABLES").fetchall()
        tables = [row[0] for row in result]
        return {"tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/query")
async def execute_query(request: Request):
    """Execute SQL query or natural language query"""
    try:
        data = await request.json()
        query = data.get("query", "")
        table_name = data.get("table_name")
        use_ai = data.get("use_ai", False)
        
        if use_ai:
            # Convert natural language to SQL
            sql_query = ai_agent.natural_language_to_sql(query, table_name)
        else:
            sql_query = query
        
        # Execute query
        result = conn.execute(sql_query).fetchall()
        columns = [desc[0] for desc in conn.description]
        
        # Convert to DataFrame for easier manipulation
        df = pd.DataFrame(result, columns=columns)
        
        # Generate chart suggestion
        chart_suggestion = ai_agent.generate_chart_suggestion(df, query)
        
        return {
            "sql_query": sql_query,
            "data": df.to_dict(orient="records"),
            "columns": columns,
            "row_count": len(df),
            "chart_suggestion": chart_suggestion
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/generate-chart")
async def generate_chart(request: Request):
    """Generate chart from data"""
    try:
        data = await request.json()
        chart_data = data.get("data", [])
        chart_type = data.get("type", "bar")
        x_col = data.get("x")
        y_col = data.get("y")
        title = data.get("title", "Chart")
        
        df = pd.DataFrame(chart_data)
        
        if chart_type == "bar":
            fig = px.bar(df, x=x_col, y=y_col, title=title)
        elif chart_type == "scatter":
            fig = px.scatter(df, x=x_col, y=y_col, title=title)
        elif chart_type == "pie":
            value_counts = df[x_col].value_counts()
            fig = px.pie(values=value_counts.values, names=value_counts.index, title=title)
        else:
            fig = px.bar(df, x=x_col, y=y_col, title=title)
        
        # Convert to JSON
        chart_json = fig.to_json()
        
        return {"chart": chart_json}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/data-sources")
async def get_data_sources():
    """Get list of configured data sources"""
    try:
        sources = data_source_manager.list_data_sources()
        # Add DuckDB as default source
        sources.insert(0, {
            'name': 'duckdb',
            'type': 'duckdb',
            'status': 'active',
            'tables': ['employees', 'sales']
        })
        return {"data_sources": sources}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/data-sources")
async def add_data_source(request: Request):
    """Add new data source"""
    try:
        data = await request.json()
        name = data.get("name")
        source_type = data.get("type")
        config = data.get("config", {})
        
        result = data_source_manager.add_data_source(name, source_type, config)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/data-sources/test")
async def test_data_source(request: Request):
    """Test data source connection"""
    try:
        data = await request.json()
        source_type = data.get("type")
        config = data.get("config", {})
        
        result = data_source_manager.test_connection(source_type, config)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/data-sources/{source_name}/tables")
async def get_source_tables(source_name: str):
    """Get tables from specific data source"""
    try:
        if source_name == 'duckdb':
            conn = duckdb.connect('app_data.db')
            result = conn.execute("SHOW TABLES").fetchall()
            tables = [row[0] for row in result]
        else:
            sources = data_source_manager.list_data_sources()
            source = next((s for s in sources if s['name'] == source_name), None)
            if not source:
                raise HTTPException(status_code=404, detail="Data source not found")
            tables = source.get('tables', [])
        
        return {"tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/query-multi-source")
async def execute_multi_source_query(request: Request):
    """Execute query on specified data source"""
    try:
        data = await request.json()
        source_name = data.get("source_name", "duckdb")
        query = data.get("query", "")
        table_name = data.get("table_name")
        use_ai = data.get("use_ai", False)
        
        if use_ai:
            # Convert natural language to SQL
            sql_query = ai_agent.natural_language_to_sql(query, table_name)
        else:
            sql_query = query
        
        # Execute query on specified data source
        if source_name == 'duckdb':
            conn = duckdb.connect('app_data.db')
            result = conn.execute(sql_query).fetchall()
            columns = [desc[0] for desc in conn.description]
        else:
            df = data_source_manager.execute_query(source_name, sql_query)
            result = df.values.tolist()
            columns = df.columns.tolist()
        
        # Convert to DataFrame for consistency
        df = pd.DataFrame(result, columns=columns)
        
        # Generate chart suggestion
        chart_suggestion = ai_agent.generate_chart_suggestion(df, query)
        
        return {
            "sql_query": sql_query,
            "data": df.to_dict(orient="records"),
            "columns": columns,
            "row_count": len(df),
            "chart_suggestion": chart_suggestion,
            "source_name": source_name
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/table-info/{source_name}/{table_name}")
async def get_multi_source_table_info(source_name: str, table_name: str):
    """Get table structure information from any data source"""
    try:
        if source_name == 'duckdb':
            conn = duckdb.connect('app_data.db')
            result = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
            columns = []
            for row in result:
                columns.append({
                    "name": row[1],
                    "type": row[2],
                    "nullable": not row[3],
                    "primary_key": bool(row[5])
                })
        else:
            table_info = data_source_manager.get_table_info(source_name, table_name)
            columns = table_info.get('columns', [])
        
        return {"table_name": table_name, "columns": columns, "source_name": source_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload-file")
async def upload_file(file: UploadFile = File(...)):
    """Upload and process data file"""
    try:
        # Create uploads directory if it doesn't exist
        upload_dir = Path("uploads")
        upload_dir.mkdir(exist_ok=True)
        
        # Save uploaded file
        file_path = upload_dir / file.filename
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        # Process file
        result = data_source_manager.upload_file(str(file_path), file.filename)
        
        # Clean up temporary file
        os.unlink(file_path)
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")

@app.get("/api/connection-guidance/{source_type}")
async def get_connection_guidance(source_type: str):
    """Get AI-powered guidance for connecting to data source"""
    try:
        guidance = ai_assistant.get_connection_guidance(source_type)
        return guidance
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ai-connection-help")
async def ai_connection_help(request: Request):
    """Get AI assistance for connection troubleshooting"""
    try:
        data = await request.json()
        source_type = data.get("source_type")
        error_message = data.get("error_message", "")
        config = data.get("config", {})
        
        # Simple AI-powered troubleshooting
        suggestions = []
        
        if "authentication" in error_message.lower() or "login" in error_message.lower():
            suggestions.append("Check username and password credentials")
            suggestions.append("Verify user has necessary permissions")
            suggestions.append("Confirm account is not locked")
        
        if "connection" in error_message.lower() or "timeout" in error_message.lower():
            suggestions.append("Verify host and port are correct")
            suggestions.append("Check network connectivity")
            suggestions.append("Ensure firewall allows connections")
        
        if "database" in error_message.lower() or "schema" in error_message.lower():
            suggestions.append("Confirm database/schema name is correct")
            suggestions.append("Check if database exists and is accessible")
        
        if not suggestions:
            suggestions.append("Check connection parameters")
            suggestions.append("Verify service is running")
            suggestions.append("Review error logs for more details")
        
        return {
            "suggestions": suggestions,
            "error_analysis": f"Connection error for {source_type}: {error_message}",
            "next_steps": [
                "Verify all connection parameters",
                "Test connection from command line if possible",
                "Contact your database administrator if issues persist"
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/deploy-app")
async def deploy_app(request: Request):
    global app_counter, deployed_apps
    
    try:
        data = await request.json()
        
        # Generate unique app ID and URL
        app_id = f"app_{app_counter:04d}"
        app_url = f"/deployed/{app_id}"
        app_counter += 1
        
        # Save app configuration
        app_config = {
            "id": app_id,
            "name": data.get("name", f"App {app_id}"),
            "template": data.get("template"),
            "data_source": data.get("dataSource"),
            "table": data.get("table"),
            "form_html": data.get("formHtml"),
            "created_at": datetime.now().isoformat(),
            "url": app_url,
            "status": "active"
        }
        
        deployed_apps[app_id] = app_config
        
        # Save to file for persistence
        import json
        with open("deployed_apps.json", "w") as f:
            json.dump(deployed_apps, f, indent=2)
        
        print(f"✅ App deployed successfully: {app_id} -> {app_url}")
        
        return JSONResponse({
            "success": True,
            "app_id": app_id,
            "url": app_url,
            "message": f"Application deployed successfully! Access it at: {app_url}"
        })
        
    except Exception as e:
        print(f"❌ Deployment error: {str(e)}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/deployed/{app_id}")
async def serve_deployed_app(app_id: str):
    """Serve a deployed application"""
    if app_id not in deployed_apps:
        raise HTTPException(status_code=404, detail="Application not found")
    
    app_config = deployed_apps[app_id]
    
    # Generate the deployed app HTML
    deployed_html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{app_config['name']} - Deployed App</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .form-control {{
            margin: 8px 0;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            background: white;
        }}
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="max-w-4xl mx-auto py-8">
        <!-- App Header -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">{app_config['name']}</h1>
                                         <p class="text-gray-600">Powered by Agentic Launchpad</p>
                </div>
                <div class="text-sm text-gray-500">
                    <i class="fas fa-database mr-1"></i>{app_config['data_source']} → {app_config['table']}
                </div>
            </div>
        </div>
        
        <!-- Deployed Application -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <div class="max-w-2xl mx-auto">
                <form id="deployedForm" class="space-y-4">
                    {app_config['form_html']}
                </form>
            </div>
        </div>
        
        <!-- App Footer -->
        <div class="text-center mt-6 text-gray-500 text-sm">
            <p>Deployed on {app_config['created_at'][:10]} | 
            <a href="/app-builder" class="text-blue-600 hover:underline">Build Your Own App</a></p>
        </div>
    </div>
    
    <script>
        // Remove control handles and make form functional
        document.querySelectorAll('.control-handle').forEach(handle => handle.remove());
        
        // Add form submission handling
        document.getElementById('deployedForm').addEventListener('submit', function(e) {{
            e.preventDefault();
            
            // Collect form data
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            // Show success message (in real app, this would save to database)
            alert('Form submitted successfully!\\n\\nData: ' + JSON.stringify(data, null, 2));
        }});
        
        // Make form inputs functional
        document.querySelectorAll('input, select, textarea').forEach(input => {{
            if (!input.name && input.type !== 'button' && input.type !== 'submit') {{
                // Generate name from label or placeholder
                const label = input.previousElementSibling;
                if (label && label.tagName === 'LABEL') {{
                    input.name = label.textContent.toLowerCase().replace(/[^a-z0-9]/g, '_');
                }}
            }}
        }});
    </script>
</body>
</html>
    """
    
    return HTMLResponse(content=deployed_html)

# Keep old deployed apps route hidden but functional for later use  
@app.get("/old-deployed-apps")
async def old_deployed_apps_page(request: Request):
    """Old deployed apps management page (hidden but preserved)"""
    return templates.TemplateResponse("deployed_apps.html", {"request": request})

@app.get("/api/deployed-apps")
async def list_deployed_apps():
    """List all deployed applications"""
    apps_list = [
        {
            "id": app_id,
            "name": config["name"],
            "template": config["template"],
            "url": config["url"],
            "created_at": config["created_at"],
            "status": config["status"]
        }
        for app_id, config in deployed_apps.items()
    ]
    
    return JSONResponse({"apps": apps_list})

@app.delete("/api/deployed-apps/{app_id}")
async def delete_deployed_app(app_id: str):
    """Delete a deployed application"""
    if app_id not in deployed_apps:
        raise HTTPException(status_code=404, detail="Application not found")
    
    del deployed_apps[app_id]
    
    # Update persistent storage
    import json
    with open("deployed_apps.json", "w") as f:
        json.dump(deployed_apps, f, indent=2)
    
    return JSONResponse({"success": True, "message": "Application deleted successfully"})

# Agent Management Routes
@app.get("/agents")
async def agent_dashboard(request: Request):
    """Agent Dashboard - Main hub for AI agent management"""
    return templates.TemplateResponse("agent_dashboard.html", {"request": request})

@app.get("/build-agents")
async def build_agents(request: Request):
    """Build/Add Agents - Create and configure new AI agents"""
    return templates.TemplateResponse("build_agents.html", {"request": request})

@app.get("/deploy-agents")
async def deploy_agents(request: Request):
    """Deploy Agents - Manage and monitor deployed AI agents"""
    return templates.TemplateResponse("deploy_agents.html", {"request": request})

@app.get("/discovery-agents")
async def discovery_agents(request: Request):
    """Discovery Agents - Intelligent content analysis and extraction"""
    return templates.TemplateResponse("discovery_agents.html", {"request": request})

@app.get("/conversational-agents")
async def conversational_agents(request: Request):
    """Conversational Agents - Natural language agent creation using Langgraph"""
    return templates.TemplateResponse("conversational_agents.html", {"request": request})

# Langflow Integration APIs
@app.post("/api/langflow/connect")
async def connect_langflow(request: Request):
    """Connect to Langflow instance and test connection"""
    try:
        data = await request.json()
        langflow_url = data.get("url", "http://localhost:7860")
        api_key = data.get("api_key", "")
        
        # Simulate connection test
        # In production, you would make actual HTTP request to Langflow
        await asyncio.sleep(1)  # Simulate network delay
        
        return JSONResponse({
            "success": True,
            "message": "Connected to Langflow successfully!",
            "langflow_url": langflow_url,
            "version": "1.0.0"
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/langflow/flows")
async def get_langflow_flows():
    """Get available flows from Langflow"""
    # Simulate available flows
    sample_flows = [
        {
            "id": "flow_001",
            "name": "Investment Analysis Agent",
            "description": "Financial investment analysis and research agent",
            "category": "business-analyst",
            "type": "investment-analysis",
            "status": "Ready",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-15T14:45:00Z"
        },
        {
            "id": "flow_002", 
            "name": "Data Migration Pipeline",
            "description": "Automated data migration between systems",
            "category": "data-engineering",
            "type": "data-migration",
            "status": "Ready",
            "created_at": "2024-01-14T09:15:00Z",
            "updated_at": "2024-01-14T16:20:00Z"
        },
        {
            "id": "flow_003",
            "name": "Document Processing Agent", 
            "description": "Extract and analyze content from various document types",
            "category": "discovery",
            "type": "document-processor",
            "status": "Ready",
            "created_at": "2024-01-13T11:45:00Z",
            "updated_at": "2024-01-13T13:30:00Z"
        }
    ]
    
    return JSONResponse({"flows": sample_flows})

@app.post("/api/langflow/import-flow")
async def import_langflow_flow(request: Request):
    """Import a specific flow from Langflow"""
    try:
        data = await request.json()
        flow_id = data.get("flow_id")
        
        # Simulate flow import
        agent_id = f"agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_id,
            "message": f"Flow {flow_id} imported successfully as agent {agent_id}"
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# JSON Import APIs  
@app.post("/api/agent/import-json")
async def import_agent_json(request: Request):
    """Import agent from JSON configuration"""
    try:
        data = await request.json()
        json_config = data.get("config", {})
        
        # Validate JSON structure
        required_fields = ["name", "description", "type"]
        for field in required_fields:
            if field not in json_config:
                return JSONResponse({
                    "success": False, 
                    "error": f"Missing required field: {field}"
                }, status_code=400)
        
        # Create agent from JSON
        agent_id = f"agent_json_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_id,
            "message": f"Agent '{json_config['name']}' imported successfully from JSON"
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/validate-json")
async def validate_agent_json(request: Request):
    """Validate agent JSON configuration"""
    try:
        data = await request.json()
        json_config = data.get("config", {})
        
        validation_results = {
            "valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Check required fields
        required_fields = ["name", "description", "type", "category"]
        for field in required_fields:
            if field not in json_config:
                validation_results["errors"].append(f"Missing required field: {field}")
                validation_results["valid"] = False
        
        # Check field types
        if "name" in json_config and not isinstance(json_config["name"], str):
            validation_results["errors"].append("Field 'name' must be a string")
            validation_results["valid"] = False
            
        if "timeout" in json_config and not isinstance(json_config["timeout"], int):
            validation_results["warnings"].append("Field 'timeout' should be an integer")
        
        return JSONResponse(validation_results)
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# API Integration
@app.post("/api/agent/test-api")
async def test_agent_api(request: Request):
    """Test API endpoint connection for agent integration"""
    try:
        data = await request.json()
        endpoint = data.get("endpoint")
        method = data.get("method", "POST")
        headers = data.get("headers", {})
        auth_type = data.get("auth_type", "none")
        auth_value = data.get("auth_value", "")
        
        # Simulate API testing
        await asyncio.sleep(2)  # Simulate network delay
        
        # In production, you would make actual HTTP request
        return JSONResponse({
            "success": True,
            "status_code": 200,
            "response_time": "150ms",
            "message": "API endpoint is reachable and responding correctly"
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/save-api-agent")
async def save_api_agent(request: Request):
    """Save API agent as draft"""
    try:
        data = await request.json()
        
        agent_config = {
            "id": f"api_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": data.get("name", "API Agent"),
            "category": data.get("category", "general"),
            "description": data.get("description", ""),
            "type": "direct-api",
            "endpoint": data.get("endpoint"),
            "inputType": data.get("inputType", "chat"),
            "outputType": data.get("outputType", "chat"),
            "testInput": data.get("testInput", "hello world!"),
            "humanInLoop": data.get("humanInLoop", True),
            "status": "draft",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store the agent (in production, use a database)
        if not hasattr(save_api_agent, 'agents'):
            save_api_agent.agents = {}
        save_api_agent.agents[agent_config["id"]] = agent_config
        
        print(f"💾 API Agent saved: {agent_config['name']} ({agent_config['id']})")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"API agent '{agent_config['name']}' saved as draft successfully",
            "agent": agent_config
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/create-api-agent")
async def create_api_agent(request: Request):
    """Create and deploy agent with direct API integration"""
    try:
        data = await request.json()
        
        agent_config = {
            "id": f"api_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": data.get("name", "API Agent"),
            "category": data.get("category", "general"),
            "description": data.get("description", ""),
            "type": "direct-api",
            "endpoint": data.get("endpoint"),
            "inputType": data.get("inputType", "chat"),
            "outputType": data.get("outputType", "chat"),
            "testInput": data.get("testInput", "hello world!"),
            "humanInLoop": data.get("humanInLoop", True),
            "status": "active",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store the agent (in production, use a database)
        if not hasattr(create_api_agent, 'agents'):
            create_api_agent.agents = {}
        create_api_agent.agents[agent_config["id"]] = agent_config
        
        print(f"🚀 API Agent created and deployed: {agent_config['name']} ({agent_config['id']})")
        print(f"   Endpoint: {agent_config['endpoint']}")
        print(f"   Category: {agent_config['category']}")
        print(f"   Types: {agent_config['inputType']} → {agent_config['outputType']}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"API agent '{agent_config['name']}' created and deployed successfully",
            "agent": agent_config
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Comprehensive Agent Creation API
@app.post("/api/agent/create")
async def create_comprehensive_agent(request: Request):
    """Create agent with full configuration including human-in-the-loop"""
    try:
        data = await request.json()
        
        # Validate required fields
        required_fields = ["name", "description", "category", "type"]
        for field in required_fields:
            if field not in data:
                return JSONResponse({
                    "success": False, 
                    "error": f"Missing required field: {field}"
                }, status_code=400)
        
        # Create comprehensive agent configuration
        agent_config = {
            "id": f"agent_{data['category']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": data["name"],
            "description": data["description"],
            "category": data["category"],
            "type": data["type"],
            "priority": data.get("priority", "medium"),
            "environment": data.get("environment", "development"),
            "schedule": data.get("schedule", "manual"),
            "timeout": data.get("timeout", 60),
            "human_in_loop": {
                "enabled": data.get("humanInLoop", {}).get("enabled", True),
                "validation_points": data.get("humanInLoop", {}).get("validationPoints", []),
                "notification_email": data.get("humanInLoop", {}).get("notificationEmail", ""),
                "escalation_timeout": data.get("humanInLoop", {}).get("escalationTimeout", 30)
            },
            "status": "created",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store agent configuration (in production, save to database)
        print(f"✅ Agent created: {agent_config['name']} ({agent_config['id']})")
        print(f"   Category: {agent_config['category']}")
        print(f"   Type: {agent_config['type']}")
        print(f"   Human-in-Loop: {'Enabled' if agent_config['human_in_loop']['enabled'] else 'Disabled'}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"🎉 Agent '{agent_config['name']}' has been created successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Agent Type Information APIs
@app.get("/api/agent/types/{category}")
async def get_agent_types_by_category(category: str):
    """Get available agent types for a specific category"""
    
    agent_types = {
        "discovery": [
            {"id": "url-search", "name": "URL Search Agent", "description": "Search and analyze content from URLs and websites"},
            {"id": "pdf-analyzer", "name": "PDF Analyzer Agent", "description": "Extract and analyze content from PDF documents"},
            {"id": "document-processor", "name": "Document Processor", "description": "Process Word docs, Excel files, and text documents"},
            {"id": "presentation-analyzer", "name": "Presentation Analyzer", "description": "Analyze PowerPoint and presentation files"},
            {"id": "metadata-extractor", "name": "Metadata Extractor", "description": "Extract and organize metadata from various sources"},
            {"id": "content-synthesizer", "name": "Content Synthesizer", "description": "Build topical summaries and knowledge bases"}
        ],
        "business-analyst": [
            {"id": "requirements-agent", "name": "Requirements Agent", "description": "Gather, analyze and document business requirements"},
            {"id": "impact-analysis", "name": "Impact Analysis Agent", "description": "Assess business impact and change implications"},
            {"id": "mapping-agent", "name": "Mapping Agent", "description": "Create process maps and workflow diagrams"},
            {"id": "brd-agent", "name": "BRD Agent", "description": "Generate Business Requirements Documents"},
            {"id": "frd-agent", "name": "FRD Agent", "description": "Create Functional Requirements Documents"}
        ],
        "data-engineering": [
            # Data Onboarding
            {"id": "data-migration", "name": "Migration Agent", "description": "Migrate data between systems", "subcategory": "onboarding"},
            {"id": "data-cleaning", "name": "Cleaning Agent", "description": "Clean and prepare data", "subcategory": "onboarding"},
            {"id": "data-modeling", "name": "Modeling Agent", "description": "Create data models", "subcategory": "onboarding"},
            {"id": "data-integration", "name": "Integration Agent", "description": "Integrate multiple sources", "subcategory": "onboarding"},
            # Data Pipeline  
            {"id": "ddk-agent", "name": "DDK Agent", "description": "Data Development Kit automation", "subcategory": "pipeline"},
            {"id": "enterprise-data-service", "name": "Enterprise Data Service", "description": "Enterprise data layer management", "subcategory": "pipeline"},
            {"id": "api-agent", "name": "API Agent", "description": "API data integration", "subcategory": "pipeline"},
            {"id": "bulk-data-agent", "name": "Bulk Data Agent", "description": "Large-scale data processing", "subcategory": "pipeline"},
            # Data Orchestrator
            {"id": "data-orchestrator", "name": "Data Orchestrator", "description": "Orchestrate complex workflows", "subcategory": "orchestrator"},
            {"id": "data-scheduler", "name": "Data Scheduler", "description": "Schedule and manage jobs", "subcategory": "orchestrator"},
            {"id": "workflow-monitor", "name": "Workflow Monitor", "description": "Monitor pipeline health", "subcategory": "orchestrator"},
            # Data Storage
            {"id": "crud-script-agent", "name": "CRUD Script Agent", "description": "Auto-generate insert/update/delete scripts", "subcategory": "storage"},
            {"id": "schema-manager", "name": "Schema Manager", "description": "Manage database schemas", "subcategory": "storage"},
            {"id": "backup-agent", "name": "Backup Agent", "description": "Automated backup and recovery", "subcategory": "storage"}
        ],
        "conversational": [
            {"id": "multi-agent-chat", "name": "Multi-Agent Chat", "description": "Intelligent routing between multiple agents"},
            {"id": "customer-support", "name": "Customer Support Chat", "description": "Automated customer service interactions"},
            {"id": "knowledge-assistant", "name": "Knowledge Assistant", "description": "Question-answering from knowledge base"}
        ]
    }
    
    if category not in agent_types:
        raise HTTPException(status_code=404, detail="Category not found")
    
    return JSONResponse({"category": category, "types": agent_types[category]})

# Human-in-the-Loop Management
@app.post("/api/agent/human-loop/validate")
async def request_human_validation(request: Request):
    """Request human validation for agent action"""
    try:
        data = await request.json()
        
        validation_request = {
            "id": f"validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "agent_id": data.get("agent_id"),
            "validation_type": data.get("validation_type"),
            "content": data.get("content"),
            "priority": data.get("priority", "medium"),
            "created_at": datetime.now().isoformat(),
            "status": "pending"
        }
        
        # In production, this would:
        # 1. Store validation request in database
        # 2. Send notification email
        # 3. Create web notification for admin dashboard
        
        print(f"🔔 Human validation requested: {validation_request['validation_type']} for agent {validation_request['agent_id']}")
        
        return JSONResponse({
            "success": True,
            "validation_id": validation_request["id"],
            "message": "Validation request submitted. You will be notified when human review is needed."
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# API Integration for Langflow
@app.post("/api/agent/test-langflow-api")
async def test_langflow_api(request: Request):
    """Test Langflow API endpoint with specific format"""
    try:
        data = await request.json()
        endpoint = data.get("endpoint")
        input_value = data.get("input_value", "hello world!")
        output_type = data.get("output_type", "chat")
        input_type = data.get("input_type", "chat")
        
        if not endpoint:
            return JSONResponse({"success": False, "error": "Endpoint is required"}, status_code=400)
        
        # Simulate API testing with Langflow format
        # In production, you would make actual HTTP request to Langflow
        import time
        start_time = time.time()
        
        # Simulate the request
        payload = {
            "input_value": input_value,
            "output_type": output_type,
            "input_type": input_type
        }
        
        await asyncio.sleep(1)  # Simulate network delay
        
        # Mock successful response
        mock_response = {
            "outputs": [
                {
                    "inputs": {"input_value": input_value},
                    "outputs": [
                        {
                            "results": {
                                "message": {
                                    "data": f"Response from Langflow: {input_value}"
                                }
                            }
                        }
                    ]
                }
            ]
        }
        
        response_time = f"{int((time.time() - start_time) * 1000)}ms"
        
        return JSONResponse({
            "success": True,
            "status_code": 200,
            "response_time": response_time,
            "api_response": str(mock_response),
            "message": "Langflow API endpoint is reachable and responding correctly"
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/create-langflow-api-agent")
async def create_langflow_api_agent(request: Request):
    """Create agent with Langflow API integration"""
    try:
        data = await request.json()
        
        agent_config = {
            "id": f"langflow_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": data.get("name", "Langflow API Agent"),
            "description": f"Langflow API agent connected to {data.get('endpoint', 'N/A')}",
            "category": data.get("category", "api-integration"),
            "type": data.get("type", "langflow-api"),
            "endpoint": data.get("endpoint"),
            "output_type": data.get("output_type", "chat"),
            "input_type": data.get("input_type", "chat"),
            "status": "active",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store agent in memory (in production, save to database)
        if not hasattr(create_langflow_api_agent, 'agents'):
            create_langflow_api_agent.agents = {}
        
        create_langflow_api_agent.agents[agent_config["id"]] = agent_config
        
        print(f"✅ Langflow API Agent created: {agent_config['name']} ({agent_config['id']})")
        print(f"   Endpoint: {agent_config['endpoint']}")
        print(f"   Types: {agent_config['input_type']} → {agent_config['output_type']}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"🎉 Langflow API agent '{agent_config['name']}' created successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Enhanced Agent Management
if not hasattr(create_langflow_api_agent, 'agents'):
    create_langflow_api_agent.agents = {}

@app.get("/api/agents")
async def list_agents():
    """List all created agents"""
    all_agents = []
    
    # Get Langflow API agents
    if hasattr(create_langflow_api_agent, 'agents'):
        all_agents.extend(list(create_langflow_api_agent.agents.values()))
    
    # Get Guided Builder agents
    if hasattr(create_guided_agent, 'agents'):
        all_agents.extend(list(create_guided_agent.agents.values()))
    
    # Get Studio agents (both saved and deployed)
    if hasattr(save_studio_agent, 'agents'):
        all_agents.extend(list(save_studio_agent.agents.values()))
    
    if hasattr(deploy_studio_agent, 'agents'):
        deployed_studio_agents = list(deploy_studio_agent.agents.values())
        # Avoid duplicates - only add if not already present
        for agent in deployed_studio_agents:
            if not any(a['id'] == agent['id'] for a in all_agents):
                all_agents.append(agent)
    
    # Get Conversational agents
    all_agents.extend(list(conversational_agents.values()))
    
    # Get Direct API agents (both saved and created)
    if hasattr(save_api_agent, 'agents'):
        all_agents.extend(list(save_api_agent.agents.values()))
    
    if hasattr(create_api_agent, 'agents'):
        created_api_agents = list(create_api_agent.agents.values())
        # Avoid duplicates - only add if not already present
        for agent in created_api_agents:
            if not any(a['id'] == agent['id'] for a in all_agents):
                all_agents.append(agent)
    
    # Add sample agents for demo only if no real agents exist
    if not all_agents:
        sample_agents = [
            {
                "id": "demo_agent_001",
                "name": "Demo Investment Analyzer",
                "description": "Sample agent for investment analysis",
                "category": "business-analyst",
                "type": "investment-analysis",
                "status": "active",
                "created_at": "2024-01-15T10:30:00Z"
            },
            {
                "id": "demo_agent_002", 
                "name": "Demo Data Processor",
                "description": "Sample agent for data processing",
                "category": "data-engineering",
                "type": "data-migration",
                "status": "active",
                "created_at": "2024-01-14T09:15:00Z"
            },
            {
                "id": "demo_agent_003", 
                "name": "Demo AI Assistant",
                "description": "Sample conversational agent powered by ChatGPT/Claude",
                "category": "conversational",
                "type": "conversational",
                "status": "active",
                "created_at": "2024-01-16T11:45:00Z"
            }
        ]
        all_agents.extend(sample_agents)
    
    # Sort agents by creation date (newest first)
    all_agents.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    
    return JSONResponse({
        "agents": all_agents,
        "count": len(all_agents),
        "success": True
    })

@app.get("/api/agents/{agent_id}")
async def get_agent(agent_id: str):
    """Get agent details"""
    # Check in Langflow API agents
    if hasattr(create_langflow_api_agent, 'agents') and agent_id in create_langflow_api_agent.agents:
        agent = create_langflow_api_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Check in Guided Builder agents
    if hasattr(create_guided_agent, 'agents') and agent_id in create_guided_agent.agents:
        agent = create_guided_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Check in Studio agents (saved)
    if hasattr(save_studio_agent, 'agents') and agent_id in save_studio_agent.agents:
        agent = save_studio_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Check in Studio agents (deployed)
    if hasattr(deploy_studio_agent, 'agents') and agent_id in deploy_studio_agent.agents:
        agent = deploy_studio_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Check in Direct API agents (saved)
    if hasattr(save_api_agent, 'agents') and agent_id in save_api_agent.agents:
        agent = save_api_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Check in Direct API agents (created)
    if hasattr(create_api_agent, 'agents') and agent_id in create_api_agent.agents:
        agent = create_api_agent.agents[agent_id]
        return JSONResponse({"agent": agent})
    
    # Demo agents (fallback)
    demo_agents = {
        "demo_agent_001": {
            "id": "demo_agent_001",
            "name": "Demo Investment Analyzer",
            "description": "Sample agent for investment analysis",
            "category": "business-analyst",
            "type": "investment-analysis",
            "status": "active"
        },
        "demo_agent_002": {
            "id": "demo_agent_002",
            "name": "Demo Data Processor", 
            "description": "Sample agent for data processing",
            "category": "data-engineering",
            "type": "data-migration",
            "status": "active"
        }
    }
    
    if agent_id in demo_agents:
        return JSONResponse({"agent": demo_agents[agent_id]})
    
    raise HTTPException(status_code=404, detail="Agent not found")

# Agent Execution Interface
@app.get("/agent/{agent_id}")
async def agent_interface(agent_id: str, request: Request):
    """Serve agent execution interface"""
    # Get agent details
    agent = None
    
    if hasattr(create_langflow_api_agent, 'agents') and agent_id in create_langflow_api_agent.agents:
        agent = create_langflow_api_agent.agents[agent_id]
    
    # Check in Direct API agents (saved)
    if not agent and hasattr(save_api_agent, 'agents') and agent_id in save_api_agent.agents:
        agent = save_api_agent.agents[agent_id]
    
    # Check in Direct API agents (created)
    if not agent and hasattr(create_api_agent, 'agents') and agent_id in create_api_agent.agents:
        agent = create_api_agent.agents[agent_id]
    
    if not agent:
        # Demo agents fallback
        demo_agents = {
            "demo_agent_001": {
                "id": "demo_agent_001",
                "name": "Demo Investment Analyzer",
                "description": "Sample agent for investment analysis",
                "category": "business-analyst",
                "type": "investment-analysis"
            },
            "demo_agent_002": {
                "id": "demo_agent_002",
                "name": "Demo Data Processor",
                "description": "Sample agent for data processing",
                "category": "data-engineering",
                "type": "data-migration"
            }
        }
        
        if agent_id in demo_agents:
            agent = demo_agents[agent_id]
    
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    # Generate agent interface HTML
    agent_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{agent['name']} - Agentic Launchpad</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/gic_theme.css">
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="gic-header">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-robot text-white text-lg"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-white">{agent['name']}</h1>
                        <p class="text-xs text-blue-200">{agent.get('category', 'Agent').title()} Agent</p>
                    </div>
                </div>
                <nav class="flex space-x-2">
                    <a href="/agents" class="gic-nav-link">← Back to Dashboard</a>
                    <a href="/deploy-agents" class="gic-nav-link">Deploy Agents</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Agent Info -->
        <div class="gic-card p-6 mb-8">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h2 class="text-2xl font-bold text-gray-900">{agent['name']}</h2>
                    <p class="text-gray-600">{agent.get('description', 'AI Agent Interface')}</p>
                </div>
                <div class="flex space-x-2">
                    <span class="gic-badge gic-badge-primary">{agent.get('category', 'general')}</span>
                    <span class="gic-badge gic-badge-success">Active</span>
                </div>
            </div>
        </div>

        <!-- Chat Interface -->
        <div class="gic-card p-6">
            <h3 class="text-lg font-semibold mb-4 text-gray-800">
                <i class="fas fa-comments mr-3 text-blue-600"></i>Chat with {agent['name']}
            </h3>
            
            <!-- Messages Area -->
            <div id="messagesArea" class="bg-gray-50 rounded-lg p-4 h-96 overflow-y-auto mb-4">
                <div class="gic-chat-message">
                    <div class="gic-message-bubble bg-blue-100 text-blue-900 ml-auto">
                        <strong>System:</strong> {agent['name']} is ready to assist you!
                    </div>
                </div>
            </div>

            <!-- Input Area -->
            <div class="flex space-x-3">
                <input 
                    type="text" 
                    id="messageInput" 
                    class="gic-input flex-1" 
                    placeholder="Type your message here..."
                    onkeypress="if(event.key==='Enter') sendMessage()"
                >
                <button id="sendBtn" onclick="sendMessage()" class="gic-btn gic-btn-primary">
                    <i class="fas fa-paper-plane mr-2"></i>Send
                </button>
            </div>
        </div>

        <!-- Agent Details -->
        <div class="gic-card p-6 mt-8">
            <h3 class="text-lg font-semibold mb-4 text-gray-800">
                <i class="fas fa-info-circle mr-3 text-blue-600"></i>Agent Details
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm font-medium text-gray-700">Agent ID</p>
                    <p class="text-sm text-gray-600">{agent['id']}</p>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-700">Category</p>
                    <p class="text-sm text-gray-600">{agent.get('category', 'N/A')}</p>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-700">Type</p>
                    <p class="text-sm text-gray-600">{agent.get('type', 'N/A')}</p>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-700">Status</p>
                    <p class="text-sm text-gray-600">{agent.get('status', 'Active')}</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        const agentId = '{agent['id']}';
        const agentEndpoint = '{agent.get('endpoint', '')}';
        const outputType = '{agent.get('output_type', 'chat')}';
        const inputType = '{agent.get('input_type', 'chat')}';

        async function sendMessage() {{
            const input = document.getElementById('messageInput');
            const sendBtn = document.getElementById('sendBtn');
            const messagesArea = document.getElementById('messagesArea');
            
            const message = input.value.trim();
            if (!message) return;

            // Add user message
            addMessage(message, 'user');
            input.value = '';
            
            // Show loading
            sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
            sendBtn.disabled = true;

            try {{
                // Call agent API
                const response = await fetch('/api/agent/execute', {{
                    method: 'POST',
                    headers: {{
                        'Content-Type': 'application/json',
                    }},
                    body: JSON.stringify({{
                        agent_id: agentId,
                        message: message,
                        endpoint: agentEndpoint,
                        input_type: inputType,
                        output_type: outputType
                    }})
                }});

                const result = await response.json();
                
                if (result.success) {{
                    addMessage(result.response, 'agent');
                }} else {{
                    addMessage('Error: ' + result.error, 'error');
                }}
            }} catch (error) {{
                addMessage('Error: Failed to communicate with agent', 'error');
            }} finally {{
                sendBtn.innerHTML = '<i class="fas fa-paper-plane mr-2"></i>Send';
                sendBtn.disabled = false;
            }}
        }}

        function addMessage(message, type) {{
            const messagesArea = document.getElementById('messagesArea');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'gic-chat-message';
            
            let bubbleClass = '';
            let sender = '';
            
            switch(type) {{
                case 'user':
                    bubbleClass = 'gic-message-bubble bg-blue-600 text-white ml-auto';
                    sender = 'You';
                    break;
                case 'agent':
                    bubbleClass = 'gic-message-bubble bg-white border border-gray-200';
                    sender = '{agent['name']}';
                    break;
                case 'error':
                    bubbleClass = 'gic-message-bubble bg-red-100 text-red-900';
                    sender = 'System';
                    break;
            }}
            
            messageDiv.innerHTML = `
                <div class="${{bubbleClass}}">
                    <strong>${{sender}}:</strong> ${{message}}
                </div>
            `;
            
            messagesArea.appendChild(messageDiv);
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }}
    </script>
</body>
</html>"""
    
    return HTMLResponse(content=agent_html)

@app.post("/api/agent/execute")
async def execute_agent(request: Request):
    """Execute agent with user input"""
    try:
        data = await request.json()
        agent_id = data.get("agent_id")
        message = data.get("message")
        endpoint = data.get("endpoint")
        input_type = data.get("input_type", "chat")
        output_type = data.get("output_type", "chat")
        
        # If it's a Langflow API agent, call the actual endpoint
        if endpoint and endpoint.startswith("http"):
            try:
                import aiohttp
                
                payload = {
                    "input_value": message,
                    "output_type": output_type,
                    "input_type": input_type
                }
                
                # In a real implementation, you would make the actual API call
                # For now, simulate a response
                await asyncio.sleep(1)
                
                response_text = f"Hello! You said: '{message}'. This is a simulated response from the Langflow agent. In production, this would be the actual response from your Langflow endpoint."
                
                return JSONResponse({
                    "success": True,
                    "response": response_text
                })
                
            except Exception as e:
                return JSONResponse({
                    "success": False,
                    "error": f"Failed to call Langflow API: {str(e)}"
                })
        else:
            # Demo response for non-API agents
            responses = [
                f"Thank you for your message: '{message}'. I'm processing this request...",
                f"Based on your input '{message}', here are my thoughts...",
                f"I understand you're asking about '{message}'. Let me help you with that.",
                f"Your message '{message}' has been analyzed. Here's what I found..."
            ]
            
            import random
            response_text = random.choice(responses)
            
            return JSONResponse({
                "success": True,
                "response": response_text
            })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Enhanced Agent Builder APIs
@app.post("/api/agent/create-guided")
async def create_guided_agent(request: Request):
    """Create agent using guided builder"""
    try:
        data = await request.json()
        
        agent_config = {
            "id": f"guided_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "name": data.get("name", "Guided Agent"),
            "description": data.get("description", ""),
            "topic": data.get("topic"),
            "topicName": data.get("topicName"),
            "capabilities": data.get("capabilities", []),
            "responseStyle": data.get("responseStyle", "professional"),
            "detailLevel": data.get("detailLevel", "detailed"),
            "humanInLoop": data.get("humanInLoop", True),
            "model": data.get("model", "gpt-4"),
            "creativity": data.get("creativity", 50),
            "instructions": data.get("instructions", ""),
            "type": "guided",
            "category": data.get("category", "general"),
            "status": "active",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store agent in memory (in production, save to database)
        if not hasattr(create_guided_agent, 'agents'):
            create_guided_agent.agents = {}
        
        create_guided_agent.agents[agent_config["id"]] = agent_config
        
        print(f"✅ Guided Agent created: {agent_config['name']} ({agent_config['id']})")
        print(f"   Topic: {agent_config['topicName']}")
        print(f"   Capabilities: {len(agent_config['capabilities'])}")
        print(f"   Style: {agent_config['responseStyle']}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"🎉 Guided agent '{agent_config['name']}' created successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/save-studio")
async def save_studio_agent(request: Request):
    """Save agent from studio builder"""
    try:
        data = await request.json()
        
        agent_id = data.get("id") or f"studio_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        agent_config = {
            "id": agent_id,
            "name": data.get("name", "Studio Agent"),
            "category": data.get("category", "general"),
            "role": data.get("role", ""),
            "skills": data.get("skills", ""),
            "guidelines": data.get("guidelines", ""),
            "variables": data.get("variables", []),
            "knowledge": data.get("knowledge", []),
            "tools": data.get("tools", []),
            "type": "studio",
            "status": "draft",
            "created_at": datetime.now().isoformat() if not data.get("id") else None,
            "updated_at": datetime.now().isoformat()
        }
        
        # Remove None values
        agent_config = {k: v for k, v in agent_config.items() if v is not None}
        
        # Store agent in memory (in production, save to database)
        if not hasattr(save_studio_agent, 'agents'):
            save_studio_agent.agents = {}
        
        save_studio_agent.agents[agent_config["id"]] = agent_config
        
        print(f"💾 Studio Agent saved: {agent_config['name']} ({agent_config['id']})")
        print(f"   Variables: {len(agent_config['variables'])}")
        print(f"   Knowledge: {len(agent_config['knowledge'])}")
        print(f"   Tools: {len(agent_config['tools'])}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"💾 Studio agent '{agent_config['name']}' saved successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/agent/deploy-studio")
async def deploy_studio_agent(request: Request):
    """Deploy agent from studio builder"""
    try:
        data = await request.json()
        
        agent_id = data.get("id") or f"studio_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        agent_config = {
            "id": agent_id,
            "name": data.get("name", "Studio Agent"),
            "category": data.get("category", "general"),
            "role": data.get("role", ""),
            "skills": data.get("skills", ""),
            "guidelines": data.get("guidelines", ""),
            "variables": data.get("variables", []),
            "knowledge": data.get("knowledge", []),
            "tools": data.get("tools", []),
            "type": "studio",
            "status": "active",
            "created_at": datetime.now().isoformat() if not data.get("id") else None,
            "updated_at": datetime.now().isoformat()
        }
        
        # Remove None values
        agent_config = {k: v for k, v in agent_config.items() if v is not None}
        
        # Store agent in memory (in production, save to database)
        if not hasattr(deploy_studio_agent, 'agents'):
            deploy_studio_agent.agents = {}
        
        deploy_studio_agent.agents[agent_config["id"]] = agent_config
        
        print(f"🚀 Studio Agent deployed: {agent_config['name']} ({agent_config['id']})")
        print(f"   Category: {agent_config['category']}")
        print(f"   Variables: {len(agent_config['variables'])}")
        print(f"   Knowledge: {len(agent_config['knowledge'])}")
        print(f"   Tools: {len(agent_config['tools'])}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_config["id"],
            "message": f"🚀 Studio agent '{agent_config['name']}' deployed successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Discovery Agents API Endpoints
@app.post("/api/discovery/start")
async def start_discovery(request: Request):
    """Start a discovery task"""
    try:
        data = await request.json()
        discovery_type = data.get("type")
        source = data.get("source")
        depth = data.get("depth", "detailed")
        
        if not discovery_type or not source:
            return JSONResponse({"success": False, "error": "Type and source are required"}, status_code=400)
        
        # Create discovery task
        task_id = f"discovery_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{discovery_type}"
        
        discovery_task = {
            "id": task_id,
            "type": discovery_type,
            "source": source,
            "depth": depth,
            "status": "processing",
            "created_at": datetime.now().isoformat(),
            "progress": 0,
            "insights": []
        }
        
        # In a real implementation, you would:
        # 1. Save the task to a database
        # 2. Queue the task for background processing
        # 3. Start the actual discovery process based on type
        
        # Simulate discovery processing based on type
        if discovery_type == "url":
            result = await process_url_discovery(source, depth)
        elif discovery_type == "pdf":
            result = await process_pdf_discovery(source, depth)
        elif discovery_type == "document":
            result = await process_document_discovery(source, depth)
        elif discovery_type == "metadata":
            result = await process_metadata_discovery(source, depth)
        else:
            result = await process_text_discovery(source, depth)
        
        discovery_task.update(result)
        
        print(f"✅ Discovery task started: {task_id} ({discovery_type})")
        
        return JSONResponse({
            "success": True,
            "task_id": task_id,
            "message": f"Discovery task started for {discovery_type}: {source}",
            "task": discovery_task
        })
        
    except Exception as e:
        print(f"❌ Discovery error: {str(e)}")
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/discovery/status/{task_id}")
async def get_discovery_status(task_id: str):
    """Get discovery task status"""
    try:
        # In a real implementation, fetch from database
        # For now, return a simulated response
        return JSONResponse({
            "success": True,
            "task_id": task_id,
            "status": "completed",
            "progress": 100,
            "insights_count": 156
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/discovery/results/{task_id}")
async def get_discovery_results(task_id: str):
    """Get discovery task results"""
    try:
        # In a real implementation, fetch from database
        # For now, return simulated results
        sample_insights = [
            {
                "type": "entity",
                "value": "Company ABC Inc.",
                "confidence": 0.95,
                "context": "Found in header section"
            },
            {
                "type": "contact",
                "value": "contact@company.com",
                "confidence": 0.88,
                "context": "Found in footer"
            },
            {
                "type": "technology",
                "value": "React, Node.js, Python",
                "confidence": 0.92,
                "context": "Technology stack mentions"
            }
        ]
        
        return JSONResponse({
            "success": True,
            "task_id": task_id,
            "insights": sample_insights,
            "summary": {
                "total_insights": len(sample_insights),
                "entities": 1,
                "contacts": 1,
                "technologies": 1
            }
        })
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

# Discovery processing functions
async def process_url_discovery(url: str, depth: str):
    """Process URL discovery"""
    import asyncio
    import random
    
    # Simulate processing time
    await asyncio.sleep(1)
    
    insights_count = {
        "basic": random.randint(20, 50),
        "detailed": random.randint(50, 150),
        "comprehensive": random.randint(150, 300)
    }
    
    return {
        "status": "completed",
        "progress": 100,
        "insights_count": insights_count.get(depth, 100),
        "summary": f"Analyzed {url} with {depth} depth analysis"
    }

async def process_pdf_discovery(pdf_source: str, depth: str):
    """Process PDF discovery"""
    import asyncio
    import random
    
    await asyncio.sleep(1.5)
    
    insights_count = {
        "basic": random.randint(30, 80),
        "detailed": random.randint(80, 200),
        "comprehensive": random.randint(200, 400)
    }
    
    return {
        "status": "completed",
        "progress": 100,
        "insights_count": insights_count.get(depth, 120),
        "summary": f"Extracted insights from PDF: {pdf_source}"
    }

async def process_document_discovery(doc_source: str, depth: str):
    """Process document discovery"""
    import asyncio
    import random
    
    await asyncio.sleep(1.2)
    
    insights_count = {
        "basic": random.randint(25, 60),
        "detailed": random.randint(60, 180),
        "comprehensive": random.randint(180, 350)
    }
    
    return {
        "status": "completed",
        "progress": 100,
        "insights_count": insights_count.get(depth, 90),
        "summary": f"Analyzed document: {doc_source}"
    }

async def process_metadata_discovery(source: str, depth: str):
    """Process metadata discovery"""
    import asyncio
    import random
    
    await asyncio.sleep(0.8)
    
    insights_count = {
        "basic": random.randint(15, 40),
        "detailed": random.randint(40, 120),
        "comprehensive": random.randint(120, 250)
    }
    
    return {
        "status": "completed",
        "progress": 100,
        "insights_count": insights_count.get(depth, 70),
        "summary": f"Extracted metadata from: {source}"
    }

async def process_text_discovery(text: str, depth: str):
    """Process text discovery"""
    import asyncio
    import random
    
    await asyncio.sleep(0.5)
    
    insights_count = {
        "basic": random.randint(10, 30),
        "detailed": random.randint(30, 100),
        "comprehensive": random.randint(100, 200)
    }
    
    return {
        "status": "completed",
        "progress": 100,
        "insights_count": insights_count.get(depth, 50),
        "summary": f"Analyzed text content ({len(text)} characters)"
    }

# ========================================
# CONVERSATIONAL AGENTS API ENDPOINTS  
# ========================================

# Store for conversational agents (in production, use a database)
conversational_agents = {}

@app.post("/api/conversational/test-connection")
async def test_conversational_connection(request: Request):
    """Test API connection for conversational agents"""
    try:
        data = await request.json()
        provider = data.get("provider")
        api_key = data.get("apiKey")
        model = data.get("model")
        
        if provider == "openai":
            # Test OpenAI connection
            openai.api_key = api_key
            response = openai.ChatCompletion.create(
                model=model,
                messages=[{"role": "user", "content": "Test connection"}],
                max_tokens=10,
                temperature=0.1
            )
            return JSONResponse({"success": True, "message": "OpenAI connection successful"})
            
        elif provider == "claude":
            # Test Claude connection
            client = anthropic.Anthropic(api_key=api_key)
            response = client.messages.create(
                model=model,
                max_tokens=10,
                messages=[{"role": "user", "content": "Test connection"}]
            )
            return JSONResponse({"success": True, "message": "Claude connection successful"})
            
        else:
            return JSONResponse({"success": False, "error": "Unsupported provider"}, status_code=400)
            
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/conversational/create-agent")
async def create_conversational_agent(request: Request):
    """Create a new conversational agent"""
    try:
        data = await request.json()
        
        agent_id = f"conv_agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        agent_config = {
            "id": agent_id,
            "name": data.get("name"),
            "category": data.get("category", "general"),
            "systemPrompt": data.get("systemPrompt"),
            "temperature": data.get("temperature", 0.7),
            "maxTokens": data.get("maxTokens", 1024),
            "provider": data.get("provider"),
            "model": data.get("model"),
            "type": "conversational",
            "status": "active",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # Store the agent (without API key for security)
        conversational_agents[agent_id] = agent_config
        
        print(f"✅ Conversational Agent created: {agent_config['name']} ({agent_id})")
        print(f"   Provider: {agent_config['provider']}")
        print(f"   Model: {agent_config['model']}")
        
        return JSONResponse({
            "success": True,
            "agent_id": agent_id,
            "message": f"🎉 Conversational agent '{agent_config['name']}' created successfully!",
            "agent": agent_config
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.get("/api/conversational/agents")
async def get_conversational_agents():
    """Get all conversational agents"""
    try:
        agents_list = list(conversational_agents.values())
        agents_list.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        return JSONResponse({
            "success": True,
            "agents": agents_list
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)

@app.post("/api/conversational/chat")
async def conversational_chat(request: Request):
    """Handle chat with conversational agents"""
    try:
        data = await request.json()
        message = data.get("message")
        agent = data.get("agent")
        api_key = data.get("apiKey")
        
        if not message or not agent:
            return JSONResponse({"success": False, "error": "Missing message or agent configuration"}, status_code=400)
        
        provider = agent.get("provider")
        model = agent.get("model")
        system_prompt = agent.get("systemPrompt", "You are a helpful assistant.")
        temperature = agent.get("temperature", 0.7)
        max_tokens = agent.get("maxTokens", 1024)
        
        if provider == "openai":
            # OpenAI ChatGPT
            openai.api_key = api_key
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ]
            
            response = openai.ChatCompletion.create(
                model=model,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature
            )
            
            ai_response = response.choices[0].message.content.strip()
            
        elif provider == "claude":
            # Anthropic Claude
            client = anthropic.Anthropic(api_key=api_key)
            
            # For Claude, we include system prompt in the user message
            full_message = f"System: {system_prompt}\n\nUser: {message}"
            
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=[{"role": "user", "content": full_message}]
            )
            
            ai_response = response.content[0].text.strip()
            
        else:
            return JSONResponse({"success": False, "error": "Unsupported provider"}, status_code=400)
        
        return JSONResponse({
            "success": True,
            "response": ai_response,
            "provider": provider,
            "model": model
        })
        
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9000) 